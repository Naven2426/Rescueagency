plugins {
    id("com.android.application")
    id("com.google.android.libraries.mapsplatform.secrets-gradle-plugin")
    id("com.google.gms.google-services")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.allapplication"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.allapplication"
        minSdk = 27
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    buildFeatures {
        viewBinding = true
    }
    packagingOptions {
        exclude ("META-INF/DEPENDENCIES")
        exclude ("META-INF/DEPENDENCIES.txt")
        exclude ("META-INF/LICENSE")
        exclude ("META-INF/LICENSE.txt")
        exclude ("META-INF/NOTICE")
        exclude ("META-INF/NOTICE.txt")
    }
}

dependencies {

    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("com.google.android.gms:play-services-maps:18.2.0")
    implementation("androidx.navigation:navigation-fragment:2.7.7")
    implementation("androidx.navigation:navigation-ui:2.7.7")
    implementation("androidx.camera:camera-view:1.3.3")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.lifecycle:lifecycle-livedata-ktx:2.7.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.7.0")
    implementation("androidx.activity:activity:1.8.0")
//    implementation("com.google.firebase:firebase-messaging:24.0.0")
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.1.5")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")
    //retrofit for api call
    implementation("com.squareup.retrofit2:retrofit:2.3.0")
    implementation("com.squareup.retrofit2:converter-gson:2.3.0")
    implementation("com.jakewharton.retrofit:retrofit2-rxjava2-adapter:1.0.0")
    implementation("com.squareup.okhttp3:okhttp:3.10.0")
    implementation("com.squareup.okhttp3:logging-interceptor:3.9.0")
    //volly for api call
    implementation("com.android.volley:volley:1.2.1")
    //glide for load image url
    implementation ("com.github.bumptech.glide:glide:4.12.0")
    implementation("com.squareup.picasso:picasso:2.71828")
    implementation("commons-io:commons-io:2.16.0")
    implementation("nl.joery.animatedbottombar:library:1.1.0")
    implementation("org.jsoup:jsoup:1.17.2")
    //google map
    implementation ("com.google.android.gms:play-services-location:21.2.0")
    implementation ("com.google.android.gms:play-services-maps:18.2.0")
    implementation ("com.google.android.libraries.places:places:3.4.0")
    implementation("com.google.maps.android:android-maps-utils:0.4+")
    implementation("io.reactivex.rxjava3:rxandroid:3.0.2")
    implementation("com.google.android.material:material:1.1.0")
    implementation("com.github.jd-alexander:library:1.1.0")
    //image slider
    implementation("com.github.denzcoskun:ImageSlideshow:0.1.2")
    implementation("com.github.dangiashish:Auto-Image-Slider:1.0.6")
    //view Pager2
    implementation("androidx.viewpager2:viewpager2:1.0.0")
    //rounded image view
    implementation("com.makeramen:roundedimageview:2.3.0")
    //mapbox
//    implementation("com.mapbox.mapboxsdk:mapbox-android-sdk:10.0.0")
    //qr code generator
    implementation("com.github.androidmads:QRGenerator:1.0.1")
    //qr code reader
    implementation("com.google.android.gms:play-services-vision:20.1.3")
    implementation("com.journeyapps:zxing-android-embedded:4.3.0")
    implementation("com.dynamsoft:dynamsoftcameraenhancer:2.1.0@aar")
    //camera
    implementation("androidx.camera:camera-lifecycle:1.3.3")
    //my dependency
    implementation(project(":QR"))
    //lottie animation
    implementation("com.airbnb.android:lottie:5.2.0")
    //Picasso
    implementation("com.squareup.picasso:picasso:2.71828")
    //firebase
    implementation(platform("com.google.firebase:firebase-bom:33.1.0"))
    implementation("com.google.firebase:firebase-analytics")
    implementation("com.google.firebase:firebase-messaging:24.0.0")
    implementation("com.google.firebase:firebase-auth:23.0.0")
    implementation("com.google.firebase:firebase-core:21.1.1")
    implementation("com.google.firebase:firebase-crashlytics-buildtools:3.0.0")
    implementation("com.google.firebase:firebase-database:21.0.0")


    //epub reader
    implementation("com.github.HamedTaherpour:ht-epub-reader-android:0.0.5")
    //folio reader not working
//    implementation("com.github.hero99team:FolioReader-Android:0.2.5")
    //epub parser
    implementation("com.github.mertakdut:EpubParser:1.0.95")
//    implementation ("org.apache.pdfbox:pdfbox:2.0.27")
//    implementation("com.tom_roush:pdfbox-android:2.0.19.0")
    implementation ("com.github.barteksc:android-pdf-viewer:2.8.2") // used for pdf Viewer
//    implementation ("com.github.folioreader:folioreader:1.0.1")// used for epub reader
//    implementation ("com.github.satyajiit:FolioReader-Android-ReVamp:v0.4")
    implementation("org.apache.poi:poi-ooxml:5.2.3") // used for doc reader
//    implementation ("com.github.codetoart:r2-shared-kotlin:1.0.4-2")
//    implementation ("com.github.codetoart:r2-streamer-kotlin:1.0.4-2")
//    implementation ("com.github.codetoart:r2-navigator-kotlin:1.0.4-2")
    //scale size unit
    implementation ("com.intuit.sdp:sdp-android:1.1.0")
    implementation ("com.intuit.ssp:ssp-android:1.1.0")
    //socket io
    implementation("io.socket:socket.io-client:2.0.0") {
        exclude(group = "org.json", module = "json")
    }
    //websocket
    implementation ("org.java-websocket:Java-WebSocket:1.5.2")

    //file picker
//    implementation("com.github.arteaprogramar:Android_MaterialFilePicker:version")

}