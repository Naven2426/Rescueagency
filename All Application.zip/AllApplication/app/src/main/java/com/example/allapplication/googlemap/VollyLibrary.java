package com.example.allapplication.googlemap;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.allapplication.api.response.volly.TutorResponse;
import com.google.maps.android.clustering.algo.PreCachingAlgorithmDecorator;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class VollyLibrary {
    Context context;
    public VollyLibrary(Context context)
    {
        this.context=context;
    }

    public void getVolly()
    {
        RequestQueue mRequestQueue=null;
        StringRequest mStringRequest=null;
        String url = "https://run.mocky.io/v3/85cf9aaf-aa4f-41bf-b10c-308f032f7ccc";
        String tutorUrl="https://tutor.zoop.me/api/courses.php";
        mRequestQueue = Volley.newRequestQueue(context);

        // String Request initialized
        mStringRequest=new StringRequest(Request.Method.POST, tutorUrl, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
//                Toast.makeText(context, "Response :" + response, Toast.LENGTH_LONG).show();
                Log.e("TAG","on response "+response.toString());
                try {
                    JSONObject jsonObject=new JSONObject(response);
                    JSONArray jsonArray=jsonObject.getJSONArray("data");

//                    Toast.makeText(context, "Response :" +data.getName(), Toast.LENGTH_LONG).show();
                    Log.e("TAG","response String message "+jsonObject.getString("message"));
//                    Log.e("TAG","response data class name "+data.getName());

                } catch (Exception e) {
                    Log.e("TAG","JSONObject Exception -> "+e.getMessage());
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(context, "onErrorResponse :" + error.networkResponse, Toast.LENGTH_LONG).show();
                Log.e("TAG","error message "+error.getMessage());
                Log.e("TAG","error network response "+error.networkResponse);
            }
        });
        mRequestQueue.add(mStringRequest);
    }
}
