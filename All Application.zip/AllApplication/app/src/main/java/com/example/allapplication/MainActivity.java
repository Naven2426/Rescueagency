package com.example.allapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.allapplication.api.response.CommonResponse;
import com.example.allapplication.chatapp.ChatActivity;
import com.example.allapplication.chatapp.ChatMainActivity;
import com.example.allapplication.chatapp.PreviousChatActivity;
import com.example.allapplication.chatapp.SocketIOActivity;
import com.example.allapplication.chatapp.mychat.MyChatActivity;
import com.example.allapplication.chatapp.mychat.WebSocketRoomActivity;
import com.example.allapplication.chatapp.mychat.WebSocketToSocketIoActivity;
import com.example.allapplication.databinding.ActivityMainBinding;
import com.example.allapplication.googlemap.BottomSheet;
import com.google.android.material.bottomsheet.BottomSheetDialog;

import org.checkerframework.checker.units.qual.A;
import org.json.JSONException;
import org.json.JSONObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity  {
    ActivityMainBinding binding;
    class Response{
        String message;

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }
    }

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        Button insertImageButton = binding.insertImageButton;
        insertImageButton.setOnClickListener(view -> {
            Intent intent=new Intent(MainActivity.this, MyChatActivity.class);
            intent.putExtra("name",binding.name.getText().toString());
            intent.putExtra("number",binding.number.getText().toString());
            startActivity(intent);
        });

    }
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.bottom_menu, menu);

        return true;
    }


    private void bottomSheetBehaviour() {
        BottomSheet bottomSheet=new BottomSheet();
        bottomSheet.show(getSupportFragmentManager(),bottomSheet.getTag());
    }
    private void bottomSheet() {
        RelativeLayout relativeLayout=findViewById(R.id.idRLBottomSheet);
        BottomSheetDialog bottom=new BottomSheetDialog(this,R.style.BottomSheetDialogTheme);
//        bottom.setContentView(R.layout.bottom_sheet_layout_for_maps_activity);
        View layout= LayoutInflater.from(this).inflate(R.layout.bottom_sheet_layout_for_maps_activity,relativeLayout);
        bottom.setContentView(layout);

        ImageView imageIV = layout.findViewById(R.id.idIVimage);
        String imageUrl="https://www.shutterstock.com/shutterstock/photos/1880417923/display_1500/stock-photo-germany-garzweiler-surface-mine-with-power-stations-frimmersdorf-neurath-and-niederaussem-1880417923.jpg";
        Glide.with(this).load(imageUrl).placeholder(R.drawable.image_loading)
                .error(R.drawable.error_image).into(imageIV);
        TextView textOneTV = layout.findViewById(R.id.idTVtext);
        TextView textTwoTV = layout.findViewById(R.id.idTVtextTwo);
        bottom.setDismissWithAnimation(true);

        textOneTV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "text", Toast.LENGTH_SHORT).show();
            }
        });
        bottom.show();
    }

}