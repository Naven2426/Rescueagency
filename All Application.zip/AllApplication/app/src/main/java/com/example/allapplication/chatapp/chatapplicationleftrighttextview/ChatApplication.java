package com.example.allapplication.chatapp.chatapplicationleftrighttextview;

import android.app.Application;
import io.socket.client.IO;
import io.socket.client.Socket;

public class ChatApplication extends Application {
    private Socket mSocket;
    private static final String URL = "http://YOUR_SERVER_IP:3000"; // Replace with your server IP and port

    @Override
    public void onCreate() {
        super.onCreate();
        try {
            mSocket = IO.socket(URL);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public Socket getSocket() {
        return mSocket;
    }
}

