package com.example.allapplication.qr;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Point;
import android.util.SparseArray;
import android.view.Display;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.WindowManager;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;

import com.google.android.gms.vision.CameraSource;
import com.google.android.gms.vision.Detector;
import com.google.android.gms.vision.barcode.Barcode;
import com.google.android.gms.vision.barcode.BarcodeDetector;

import java.io.IOException;

import androidmads.library.qrgenearator.QRGContents;
import androidmads.library.qrgenearator.QRGEncoder;

public class QRClass {
    private Context context;
    public static final int REQUEST_CAMERA_PERMISSION=200;
    private FragmentActivity activity;
    private String s;

    public QRClass(Context context) {
        this.context = context;
    }
    public Bitmap generateQR(String str)
    {
        WindowManager manager;
        QRGEncoder qrGenerator;
        if(!str.isEmpty()){
            manager =(WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
            Display display=manager.getDefaultDisplay();
            Point point= new Point();
            display.getSize(point);
            int width=point.x;
            int height=point.y;
            int dimen=width<height? width:height;
            dimen=dimen*3/4;
            qrGenerator=new QRGEncoder(str,null, QRGContents.Type.TEXT,dimen);
            return qrGenerator.getBitmap();
        }else{
            Toast.makeText(context, "Text is empty", Toast.LENGTH_SHORT).show();
            return null;
        }
    }
    public String scanQR(SurfaceView surface)
    {
        if(surface==null) return null;
        BarcodeDetector barcodeDetector= new BarcodeDetector.Builder(context)
                .setBarcodeFormats(Barcode.ALL_FORMATS).build();
        CameraSource cameraSource= new CameraSource.Builder(context , barcodeDetector)
                .setRequestedPreviewSize(1920 , 1080)
                .setAutoFocusEnabled(true) //you should add this feature
                .build();
        surface.getHolder().addCallback(new SurfaceHolder.Callback() {
            @Override
            public void surfaceCreated(SurfaceHolder holder) {
                try {
                    if (ActivityCompat.checkSelfPermission(context , Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        cameraSource.start(surface.getHolder());
                    } else {
                        ActivityCompat.requestPermissions(activity , new String[]{Manifest.permission.CAMERA} ,
                                REQUEST_CAMERA_PERMISSION);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void surfaceChanged(@NonNull SurfaceHolder holder , int format , int width , int height) {

            }

            @Override
            public void surfaceDestroyed(@NonNull SurfaceHolder holder) {
                cameraSource.stop();
            }
        });

        barcodeDetector.setProcessor(new Detector.Processor<Barcode>() {
            @Override
            public void release() {
                Toast.makeText(context , "To prevent memory leaks barcode scanner has been stopped" , Toast.LENGTH_SHORT).show();
            }
            @Override
            public void receiveDetections(@NonNull Detector.Detections<Barcode> detections) {
                final SparseArray<Barcode> barcodes = detections.getDetectedItems();
                if (barcodes.size() != 0) {
                    s= barcodes.valueAt(0).displayValue;
                }
            }
        });
        return s;
    }

}
