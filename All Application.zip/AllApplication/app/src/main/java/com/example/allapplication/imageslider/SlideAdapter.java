package com.example.allapplication.imageslider;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import com.example.allapplication.R;
import com.makeramen.roundedimageview.RoundedImageView;

import java.util.List;

public class SlideAdapter extends RecyclerView.Adapter<SlideAdapter.SliderImageViewHolder> {

    ViewPager2 viewPager2;
    List<SlideItem> slideItems;

    public SlideAdapter(ViewPager2 viewPager2, List<SlideItem> slideItems) {
        this.viewPager2 = viewPager2;
        this.slideItems = slideItems;
    }

    @NonNull
    @Override
    public SliderImageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.slide_item_container,parent,false);
        return new SliderImageViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SliderImageViewHolder holder, int position) {
        holder.setImage(slideItems.get(position));
        holder.showAmount.setText(slideItems.get(position).getShowAmount());

        if(position==slideItems.size()-2)
        {
            viewPager2.post(runnable);
        }
    }

    @Override
    public int getItemCount() {
        return slideItems.size();
    }
    private Runnable runnable=new Runnable() {
        @Override
        public void run() {
            slideItems.addAll(slideItems);
            notifyDataSetChanged();
        }
    };

    class SliderImageViewHolder extends  RecyclerView.ViewHolder{
        RoundedImageView roundedImageView;
        TextView showAmount;

        public SliderImageViewHolder(@NonNull View itemView) {
            super(itemView);
            this.roundedImageView=itemView.findViewById(R.id.imageSlide);
            showAmount=itemView.findViewById(R.id.showAmount);
        }
        void setImage(SlideItem slideItem)
        {
            roundedImageView.setImageResource(slideItem.getImage());
        }
    }

}
