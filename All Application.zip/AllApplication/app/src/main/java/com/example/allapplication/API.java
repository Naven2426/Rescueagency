package com.example.allapplication;

import com.example.allapplication.api.response.CommonResponse;
import com.example.allapplication.api.response.GoogleMapResponse;
import com.example.allapplication.api.response.chat.ChatResponse;
import com.example.allapplication.api.response.map.ditance.DitanceAndDurationRoot;
import com.example.allapplication.api.response.map.nearbyapi.NearbyRoot;

import org.json.JSONObject;

import java.util.List;
import java.util.Map;

import okhttp3.MultipartBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Query;
import retrofit2.http.QueryMap;

public interface API {

    @Multipart
    @POST("multiple_image.php")
    Call<CommonResponse> postMultipleImages(@Part("content")String name, @Part List<MultipartBody.Part> image);

    @GET("distancematrix/json")
    Call<GoogleMapResponse> getDistance(@Query("key")String key,@Query("origins")String origin,
                                          @Query("destinations")String destination);

    @GET("distancematrix/json")
    Call<DitanceAndDurationRoot> getDistanceInfo(@QueryMap Map<String, String> parameters);
    Call<GoogleMapResponse> getDistanceInfo1(@QueryMap Map<String, String> parameters);


    @GET("place/nearbysearch/json")
    Call<NearbyRoot> nearByLocation(
            @Field("keyword")String keyword,@Field("location")String location,
            @Field("radius")String radius,@Field("type")String type,
            @Field("key")String key
    );

    @GET("directions/json")
    Call<NearbyRoot> directionApi(@QueryMap Map<String, String> parameters);

    @Multipart
    @POST("use/rescue_agency_register")
    Call<CommonResponse> agencyRegister(@Part("agency_name")String agency_name,
                                        @Part("type_of_service")String type_of_service,
                                        @Part("address")String address,
                                        @Part("mobile")String mobile,
                                        @Part("total_members")String total_members,
                                        @Part MultipartBody.Part pdf,
                                        @Part("email")String email,
                                        @Part("username")String username,
                                        @Part("password")String password,
                                        @Part("user_type")String user_type);

    @Multipart
    @POST("imageUpload")
    Call<CommonResponse> pdfUpload(@Part("text")String agency_name, @Part MultipartBody.Part pdf);

    @POST("/object")
    Call<CommonResponse> sendBody(@Body JSONObject jsonObject);

    @GET("/chat")
    Call<ChatResponse> getChat(@Query("room_id")String room_id);
}
