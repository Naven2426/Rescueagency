package com.example.allapplication.pushnotification;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentTransaction;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import android.app.AlertDialog;
import android.app.Application;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import android.Manifest;
import android.provider.Settings;
import android.widget.Toast;

import com.example.allapplication.R;
import com.example.allapplication.databinding.ActivityNotificationBinding;

@RequiresApi(api = Build.VERSION_CODES.TIRAMISU)
public class NotificationActivity extends AppCompatActivity {

    private static final int NOTIFICATION_PERMISSION_CODE = 123;
    private static final String POST_NOTIFICATION = Manifest.permission.POST_NOTIFICATIONS;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);
        FragmentTransaction transaction=getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.frameLayout,new ProfileFragment()).addToBackStack(null).commit();;
        if (ActivityCompat.checkSelfPermission(this,POST_NOTIFICATION) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Permission not granted POST_NOTIFICATIONS", Toast.LENGTH_SHORT).show();
//            requestNotificationPermission();
            ActivityCompat.requestPermissions(this, new String[]{POST_NOTIFICATION}, NOTIFICATION_PERMISSION_CODE );

        }
        else {
            Toast.makeText(this, "Permission granted POST_NOTIFICATIONS", Toast.LENGTH_SHORT).show();
        }

        }
    private void requestNotificationPermission() {
        if (ContextCompat.checkSelfPermission(this, POST_NOTIFICATION) == PackageManager.PERMISSION_GRANTED)
            return;
        ActivityCompat.requestPermissions(this, new String[]{POST_NOTIFICATION}, NOTIFICATION_PERMISSION_CODE );
    }

    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permission, @NonNull int[] grantResult) {
        super.onRequestPermissionsResult(requestCode, permission, grantResult);
        if (requestCode == NOTIFICATION_PERMISSION_CODE ) {

            // If permission is granted
            if (grantResult.length > 0 && grantResult[0] == PackageManager.PERMISSION_GRANTED) {
                // Displaying a toast
                Toast.makeText(this, "Permission granted for POST_NOTIFICATIONS", Toast.LENGTH_LONG).show();
            } else
                // Displaying another toast if permission is not granted
                if (!ActivityCompat.shouldShowRequestPermissionRationale(NotificationActivity.this, POST_NOTIFICATION)) {
//                    Toast.makeText(NotificationActivity.this, "Permission Denied dialog", Toast.LENGTH_SHORT).show();

                    AlertDialog.Builder builder = new AlertDialog.Builder(NotificationActivity.this);
                    builder.setMessage("this feature is unavailable because this ").setTitle("Permission Require").setCancelable(false)
                            .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            }).setPositiveButton("setting", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                                    Uri uri = Uri.fromParts("package", NotificationActivity.this.getPackageName(), null);
                                    intent.setData(uri);
                                    startActivity(intent);
                                    dialog.dismiss();
                                }
                            });
                    builder.show();

                }else{
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        requestNotificationPermission();
                    }
                }

        }
    }


}