package com.example.allapplication.api.response.map.nearbyapi;

import java.util.List;

public class NearbyRoot {
    private List<String> htmlAttributions;
    private List<Results> results;
    private String status;
    private String error_message;

    public String getError_message() {
        return error_message;
    }

    public void setError_message(String error_message) {
        this.error_message = error_message;
    }

    public void setHtmlAttributions(List<String> htmlAttributions) {
        this.htmlAttributions = htmlAttributions;
    }
    public List<String> getHtmlAttributions() {
        return htmlAttributions;
    }
    public void setResults(List<Results> results) {
        this.results = results;
    }
    public List<Results> getResults() {
        return results;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public String getStatus() {
        return status;
    }
}