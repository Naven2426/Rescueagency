package com.example.allapplication.api.response.map.ditance;

public class Duration {
    private String text;
    private int value;

    public void setText(String text) {
        this.text = text;
    }
    public String getText() {
        return text;
    }
    public void setValue(int value) {
        this.value = value;
    }
    public int getValue() {
        return value;
    }
}
