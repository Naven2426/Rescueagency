package com.example.allapplication.showhidtoolbar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.allapplication.R;
import com.makeramen.roundedimageview.RoundedImageView;

import java.util.ArrayList;
import java.util.List;

public class ScrolToHideToolbarActivity extends AppCompatActivity {

    RelativeLayout mMainToolbarLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scrol_to_hide_toolbar);
        mMainToolbarLayout=findViewById(R.id.main_toolbar_layout);
       FragmentTransaction transaction=getSupportFragmentManager().beginTransaction();
       transaction.replace(R.id.framelayout,new HomeFragment()).commit();
    }
    private void scrollFunction(RecyclerView recyclerView)
    {
        String text="17% off Lmited Time Deal";
        List<FistGridCardViewRecyclerDataClass> datas=new ArrayList<>();
        datas.add(new FistGridCardViewRecyclerDataClass("https://images.unsplash.com/photo-1489389944381-3471b5b30f04?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8b3BlbiUyMHNvdXJjZXxlbnwwfHwwfHx8MA%3D%3D",text));
        datas.add(new FistGridCardViewRecyclerDataClass("https://images.unsplash.com/photo-1489389944381-3471b5b30f04?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8b3BlbiUyMHNvdXJjZXxlbnwwfHwwfHx8MA%3D%3D",text));
        datas.add(new FistGridCardViewRecyclerDataClass("https://images.unsplash.com/photo-1489389944381-3471b5b30f04?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8b3BlbiUyMHNvdXJjZXxlbnwwfHwwfHx8MA%3D%3D",text));
        datas.add(new FistGridCardViewRecyclerDataClass("https://images.unsplash.com/photo-1489389944381-3471b5b30f04?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8b3BlbiUyMHNvdXJjZXxlbnwwfHwwfHx8MA%3D%3D",text));
        datas.add(new FistGridCardViewRecyclerDataClass("https://images.unsplash.com/photo-1489389944381-3471b5b30f04?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8b3BlbiUyMHNvdXJjZXxlbnwwfHwwfHx8MA%3D%3D",text));
        datas.add(new FistGridCardViewRecyclerDataClass("https://images.unsplash.com/photo-1489389944381-3471b5b30f04?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8b3BlbiUyMHNvdXJjZXxlbnwwfHwwfHx8MA%3D%3D",text));
        datas.add(new FistGridCardViewRecyclerDataClass("https://images.unsplash.com/photo-1489389944381-3471b5b30f04?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8b3BlbiUyMHNvdXJjZXxlbnwwfHwwfHx8MA%3D%3D",text));
        datas.add(new FistGridCardViewRecyclerDataClass("https://images.unsplash.com/photo-1489389944381-3471b5b30f04?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8b3BlbiUyMHNvdXJjZXxlbnwwfHwwfHx8MA%3D%3D",text));
        datas.add(new FistGridCardViewRecyclerDataClass("https://images.unsplash.com/photo-1489389944381-3471b5b30f04?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8b3BlbiUyMHNvdXJjZXxlbnwwfHwwfHx8MA%3D%3D",text));
        datas.add(new FistGridCardViewRecyclerDataClass("https://images.unsplash.com/photo-1489389944381-3471b5b30f04?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8b3BlbiUyMHNvdXJjZXxlbnwwfHwwfHx8MA%3D%3D",text));
        datas.add(new FistGridCardViewRecyclerDataClass("https://images.unsplash.com/photo-1489389944381-3471b5b30f04?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8b3BlbiUyMHNvdXJjZXxlbnwwfHwwfHx8MA%3D%3D",text));
        GridLayoutManager grid=new GridLayoutManager(this,2);
        FistGridCardViewRecyclerView adapter=new FistGridCardViewRecyclerView(datas,this,ScrolToHideToolbarActivity.this);
        recyclerView.setLayoutManager(grid);
        recyclerView.setAdapter(adapter);
    }
    public class FistGridCardViewRecyclerDataClass {
        private String image;
        private String text;

        public String getImage() {
            return image;
        }

        public void setImage(String image) {
            this.image = image;
        }

        public String getText() {
            return text;
        }

        public void setText(String text) {
            this.text = text;
        }

        public FistGridCardViewRecyclerDataClass(String image, String text) {
            this.image = image;
            this.text = text;
        }
    }
    public class FistGridCardViewRecyclerView extends RecyclerView.Adapter<FistGridCardViewRecyclerView.MyViewHolder> {
        List<FistGridCardViewRecyclerDataClass> list;
        Context context;
        FragmentActivity activity;
        public FistGridCardViewRecyclerView(List<FistGridCardViewRecyclerDataClass> list, Context context, FragmentActivity activity) {
            this.list = list;
            this.context = context;
            this.activity = activity;
        }

        @NonNull
        @Override
        public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.fist_grid_card_layout_for_home,parent,false);
            return new MyViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
            FistGridCardViewRecyclerDataClass my=list.get(position);
            Glide.with(context).load(my.getImage()).placeholder(R.drawable.image_loading)
                    .error(R.drawable.error_image).into(holder.roundedImageView);
            holder.textView.setText(my.getText());


        }

        @Override
        public int getItemCount() {
            return list.size();
        }

        public class MyViewHolder extends RecyclerView.ViewHolder{
            CardView cardView;
            RoundedImageView roundedImageView;
            TextView textView;
            public MyViewHolder(@NonNull View itemView) {
                super(itemView);
                cardView=itemView.findViewById(R.id.materialCardView);
                roundedImageView=itemView.findViewById(R.id.cardImage);
                textView=itemView.findViewById(R.id.showAmountDetails);
            }
        }
    }
}