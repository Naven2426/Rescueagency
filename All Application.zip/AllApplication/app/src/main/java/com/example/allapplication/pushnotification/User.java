package com.example.allapplication.pushnotification;

public class User {
    private String token;
    private String email;

    public User(String token, String email) {
        this.token = token;
        this.email = email;
    }
}
