package com.example.allapplication.chatapp.kotline

import io.socket.client.IO
import io.socket.client.Socket

object SocketHandler {
    lateinit var mSocket: Socket
    @Synchronized
    fun setSocket() {
        try {
            mSocket = IO.socket("https://a1bd-2409-4072-484-7f38-10b3-1e3b-ad4e-1856.ngrok-free.app")
        }catch (e : Exception)
        {

        }
    }
    @Synchronized
    fun getSocket():Socket{
        return mSocket
    }
}
