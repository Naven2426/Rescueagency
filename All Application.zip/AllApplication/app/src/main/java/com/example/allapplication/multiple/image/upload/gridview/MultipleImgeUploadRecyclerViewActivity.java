package com.example.allapplication.multiple.image.upload.gridview;

import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.example.allapplication.API;
import com.example.allapplication.R;
import com.example.allapplication.api.response.CommonResponse;
import com.example.allapplication.multiple.images.upload.FileUtils;
import com.example.allapplication.multipleimages.recyclerview.ImageListAdapter;
import com.example.allapplication.multipleimages.recyclerview.MultiUploadActivity;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.RequestBody;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MultipleImgeUploadRecyclerViewActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    Button bSelect,bSend;
    List<Uri> images=new ArrayList<>();
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_multiple_imge_upload_recycler_view);
        recyclerView=findViewById(R.id.show);
        bSelect=findViewById(R.id.select);
        bSend=findViewById(R.id.send);
        bSelect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent gallery = new Intent(Intent.ACTION_GET_CONTENT);
                gallery.setType("image/*");
                gallery.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
                try{
                    startActivityForResult(gallery, 1);
                }catch (Exception e)
                {
                     e.printStackTrace();
                }
            }
        });
    }
    private void apiCall()
    {
        List<MultipartBody.Part> list = new ArrayList<>();
        for(Uri uri: images){
            File file = new File(uri.getPath());
            RequestBody requestBody = RequestBody.create(MediaType.parse("image/*"), file);
            list.add(MultipartBody.Part.createFormData("img[]", file.getName(), requestBody));
        }
        RequestBody name = RequestBody.create(MediaType.parse("text/plain"), "java");

        HttpLoggingInterceptor httpLoggingInterceptor = new HttpLoggingInterceptor();
        httpLoggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(60, TimeUnit.SECONDS)
                .writeTimeout(60, TimeUnit.SECONDS)
                .readTimeout(60, TimeUnit.SECONDS)
                .addInterceptor(httpLoggingInterceptor)
//                .retryOnConnectionFailure(true)
                .build();

        Retrofit retrofit = new Retrofit.Builder()
                .addConverterFactory(GsonConverterFactory.create())
                .baseUrl("https://2622-2409-4072-683-8f65-7052-41cf-a54d-2132.ngrok-free.app/Maid/mhms/api/")  //Change server URL
//                .client(client)
                .build();

        API api=retrofit.create(API.class);
        Call<CommonResponse> call = api.postMultipleImages("name",list);
        call.enqueue(new Callback<CommonResponse>() {
            @Override
            public void onResponse(Call<CommonResponse> call, Response<CommonResponse> response) {
                if(response.isSuccessful())
                {
                    CommonResponse model = response.body();
                    if(model.getStatus()==200)
                    {
                        Toast.makeText(MultipleImgeUploadRecyclerViewActivity.this, model.getMessage(), Toast.LENGTH_LONG).show();
                    }
                    else{
                        Toast.makeText(MultipleImgeUploadRecyclerViewActivity.this, model.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
                else{
                    Toast.makeText(MultipleImgeUploadRecyclerViewActivity.this, "server busy", Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<CommonResponse> call, Throwable t) {
                Log.e("TAG",t.getMessage());
                Toast.makeText(MultipleImgeUploadRecyclerViewActivity.this,"onFailure "+ t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // When an Image is picked
        if(resultCode!=RESULT_CANCELED)
        {
            if(requestCode==1)
            {
                if(resultCode==RESULT_OK && data!=null)
                {
                    int count=data.getClipData().getItemCount();
                    for(int i=0;i<count;i++)
                    {
                        Uri image=data.getClipData().getItemAt(i).getUri();
                        String imagePath= FileUtils.getPath(MultipleImgeUploadRecyclerViewActivity.this,image);
                        images.add(Uri.parse(imagePath));
                    }
                    MyRecyclerView ila=new MyRecyclerView(images,MultipleImgeUploadRecyclerViewActivity.this);
                    GridLayoutManager layoutManager = new GridLayoutManager(this, 2);

                    recyclerView.setLayoutManager(layoutManager);
                    recyclerView.setAdapter(ila);
                }
            }

        }
        bSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                apiCall();
            }
        });
    }
   private  class MyRecyclerView extends RecyclerView.Adapter<MyRecyclerView.MyViewHolder> {

        Context context;
        List<Uri> list;
        MyRecyclerView(List<Uri> list, Context context)
        {
            this.context=context;
            this.list=list;
        }

        @NonNull
        @Override
        public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view=LayoutInflater.from(context).inflate(R.layout.item_image,null);
            return new MyViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") int position) {
            File file=new File(list.get(position).getPath());
            Glide.with(context).load(file).apply(new RequestOptions().placeholder(R.drawable.edit_profile) // Placeholder image
                            .error(R.drawable.logo)) // Error image in case of loading failure
                    .into(holder.imageView);
            holder.imageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    list.remove(position);
                    Toast.makeText(context, ""+position, Toast.LENGTH_SHORT).show();

//                    holder.lin.setVisibility(View.GONE);
//                new MyRecyclerView(list,context);
                }
            });

        }

       @Override
       public int getItemCount() {
            return list.size();
    }
       private class MyViewHolder extends RecyclerView.ViewHolder{
            ImageView imageView;
            LinearLayout lin;
            public MyViewHolder(@NonNull View itemView) {
                super(itemView);
                imageView=itemView.findViewById(R.id.image);
                lin=itemView.findViewById(R.id.main);
            }
        }
    }
}
