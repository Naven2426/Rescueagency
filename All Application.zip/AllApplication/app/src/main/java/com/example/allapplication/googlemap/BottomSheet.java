package com.example.allapplication.googlemap;

import android.app.Dialog;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.allapplication.R;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

public class BottomSheet extends BottomSheetDialogFragment {
    BottomSheetDialog dialog;
    BottomSheetBehavior sheetBehavior;
    View rootView;

    @NonNull
    public Dialog onCreateDialog(@Nullable Bundle bundle){
        dialog=(BottomSheetDialog)  super.onCreateDialog(bundle);
        return dialog;
    }
    public View onCreateView(@NonNull LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle){
        rootView=layoutInflater.inflate(R.layout.bottom_sheet_layout_for_maps_activity,viewGroup,false);
        return rootView;
    }
    public void onViewCreated(@NonNull View view,@Nullable Bundle bundle)
    {
        super.onViewCreated(view,bundle);
        sheetBehavior=BottomSheetBehavior.from((View) view.getParent());
        sheetBehavior.setState(BottomSheetBehavior.STATE_HALF_EXPANDED);
        RelativeLayout relativeLayout=dialog.findViewById(R.id.idRLBottomSheet);
        relativeLayout.setMinimumHeight(Resources.getSystem().getDisplayMetrics().heightPixels);
    }

}
