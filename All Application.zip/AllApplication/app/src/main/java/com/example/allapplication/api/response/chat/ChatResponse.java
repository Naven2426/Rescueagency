package com.example.allapplication.api.response.chat;

import java.util.List;

public class ChatResponse {

    List<Results> result;

    public List<Results> getResult() {
        return result;
    }

    public ChatResponse setResult(List<Results> result) {
        this.result = result;
        return this;
    }

    public static class Results{
        private String id;
        private String mobile;
        private String room_id;
        private String messages;
        private String timestamp;
        private String user_name;

        public String getUser_name() {
            return user_name;
        }


        public String getId() {
            return id;
        }

        public String getMobile() {
            return mobile;
        }


        public String getRoom_id() {
            return room_id;
        }


        public String getMessage() {
            return messages;
        }

        public String getTimestamp() {
            return timestamp;
        }


    }
}
