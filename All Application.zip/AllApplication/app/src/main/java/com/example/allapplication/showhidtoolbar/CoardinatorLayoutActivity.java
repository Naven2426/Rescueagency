package com.example.allapplication.showhidtoolbar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.allapplication.R;

public class CoardinatorLayoutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_coardinator_layout);
    }
}