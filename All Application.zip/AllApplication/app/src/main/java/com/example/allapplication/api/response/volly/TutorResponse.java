package com.example.allapplication.api.response.volly;

import java.util.Date;
import java.util.List;

public class TutorResponse {
    private int status;
    private String message;
    private List<Data> data;

    public void setStatus(int status) {
        this.status = status;
    }
    public int getStatus() {
        return status;
    }
    public void setMessage(String message) {
        this.message = message;
    }
    public String getMessage() {
        return message;
    }
    public void setData(List<Data> data) {
        this.data = data;
    }
    public List<Data> getData() {
        return data;
    }
    public class Data {
        private Date id;
        private String name;
        private String code;
        private String image;
        private String categories;
        private String category_name;

        public void setId(Date id) {
            this.id = id;
        }
        public Date getId() {
            return id;
        }
        public void setName(String name) {
            this.name = name;
        }
        public String getName() {
            return name;
        }
        public void setCode(String code) {
            this.code = code;
        }
        public String getCode() {
            return code;
        }
        public void setImage(String image) {
            this.image = image;
        }
        public String getImage() {
            return image;
        }
        public void setCategories(String categories) {
            this.categories = categories;
        }
        public String getCategories() {
            return categories;
        }
        public void setCategory_name(String category_name) {
            this.category_name = category_name;
        }
        public String getCategory_name() {
            return category_name;
        }
    }

}
