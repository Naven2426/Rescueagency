package com.example.allapplication.pushnotification;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;



import com.example.allapplication.R;
import com.example.allapplication.databinding.FragmentNotificationBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.iid.FirebaseInstanceIdReceiver;
import com.google.firebase.messaging.FirebaseMessaging;

public class NotificationFragment extends Fragment {
    public static final String CHANNEL_ID = "simplified_coding";
    public static final String CHANNEL_NAME = "Simplified coding";
    public static final String CHANNEL_DESC = "Simplified Coding Notification";
    AppCompatEditText email,password;
    AppCompatButton sendNotification;
    FirebaseAuth mAuth;
    FragmentNotificationBinding binding;
    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_notification, container, false);
        email = view.findViewById(R.id.email);
//        binding=FragmentNotificationBinding.bind(getView());
        password = view.findViewById(R.id.password);
        sendNotification = view.findViewById(R.id.id_send_notification);
        mAuth = FirebaseAuth.getInstance();
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.TIRAMISU){
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,CHANNEL_NAME, NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription(CHANNEL_DESC);
            Toast.makeText(requireContext(), "Permission granted", Toast.LENGTH_SHORT).show();
            NotificationManager manager=requireContext().getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
        sendNotification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createUser();

            }
        });
        return view;
    }

    public void displayNotification() {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(requireContext(), CHANNEL_ID);
        builder.setSmallIcon(R.drawable.ic_launcher_background);
        builder.setContentTitle("Hurry! It is Working...");
        builder.setContentText("Your first notification");
        builder.setPriority(NotificationCompat.PRIORITY_DEFAULT);
        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(requireContext());
        if (ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(requireContext(), "Permission denied", Toast.LENGTH_SHORT).show();
            return;
        }
        notificationManager.notify(1, builder.build());
    }

    //tutorial 3 fcm token
    private void FCMtoken(){
        FirebaseMessaging.getInstance().getToken().addOnCompleteListener(new OnCompleteListener<String>() {
            @Override
            public void onComplete(@NonNull Task<String> task) {
                if(task.isSuccessful()){
                    String token = task.getResult();
                    Log.d("FCM_TOKEN",token);
                }else{
                    Log.d("FCM_ERROR_TOKEN",task.getException().getMessage());
                }
            }
        });
    }
    private void startProfileFragment(){

        Intent intent=new Intent(requireContext(),NotificationMessageActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
//        requireActivity().finish();
    }
    public void onStart(){
        super.onStart();
        if(mAuth.getCurrentUser()!=null){
            startProfileFragment();
        }
    }
    private void createUser()
    {
       String email = this.email.getText().toString();
        String password=this.password.getText().toString();
       mAuth.createUserWithEmailAndPassword(email,password)
               .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                   @Override
                   public void onComplete(@androidx.annotation.NonNull Task<AuthResult> task) {
                       if(task.isSuccessful()){
                           startProfileFragment();
                       }
                       else{
                            if(task.getException() instanceof FirebaseAuthUserCollisionException){
                                userLogin(email,password);
                            }
                            else{
                                Toast.makeText(requireContext(), "create user "+task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                Log.d("ERROR","create user "+task.getException().getMessage());
                            }
                       }
                   }
               });
    }
    private void userLogin(String email,String password){
        mAuth.signInWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@androidx.annotation.NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    startProfileFragment();
                }
                else{
                    Toast.makeText(requireContext(), "in signIn "+task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    Log.d("ERROR","in signIn "+task.getException().getMessage());
                }
            }
        });
    }

}