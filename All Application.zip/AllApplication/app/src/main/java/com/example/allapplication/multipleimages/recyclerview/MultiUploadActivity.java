package com.example.allapplication.multipleimages.recyclerview;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.example.allapplication.API;
import com.example.allapplication.R;
import com.example.allapplication.api.response.CommonResponse;
import com.example.allapplication.multiple.images.upload.FileUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.RequestBody;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MultiUploadActivity extends AppCompatActivity {

    private Button btnAdd, btnSubmit;
    private ListView imageList;
    private List<Uri> images=new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_multi_upload);
        btnAdd = findViewById(R.id.btn_add);
        btnSubmit = findViewById(R.id.btn_upload);
        imageList = findViewById(R.id.image_list);
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent gallery = new Intent(Intent.ACTION_GET_CONTENT);
                gallery.setType("image/*");
                gallery.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
                startActivityForResult(gallery, 1);
            }
        });
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                uploadToServer();
            }
        });
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // When an Image is picked
        if(resultCode!=RESULT_CANCELED)
        {
            switch (requestCode)
            {
                case 1:
                    if(resultCode==RESULT_OK && data!=null)
                    {
                        int count=data.getClipData().getItemCount();
                        for(int i=0;i<count;i++)
                        {
                            Uri image=data.getClipData().getItemAt(i).getUri();
                            String imagePath= FileUtils.getPath(MultiUploadActivity.this,image);
                            images.add(Uri.parse(imagePath));
                        }
                        ImageListAdapter ila=new ImageListAdapter(images,MultiUploadActivity.this);
                        imageList.setAdapter(ila);
                    }
            }
        }
    }

    public void uploadToServer(){

        List<MultipartBody.Part> list = new ArrayList<>();
        for(Uri uri: images){
            list.add(prepairFiles("img[]", uri));
        }
        RequestBody name = RequestBody.create(MediaType.parse("text/plain"), "java");

        HttpLoggingInterceptor httpLoggingInterceptor = new HttpLoggingInterceptor();
        httpLoggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(60, TimeUnit.SECONDS)
                .writeTimeout(60, TimeUnit.SECONDS)
                .readTimeout(60, TimeUnit.SECONDS)
                .addInterceptor(httpLoggingInterceptor)
//                .retryOnConnectionFailure(true)
                .build();

        Retrofit retrofit = new Retrofit.Builder()
                .addConverterFactory(GsonConverterFactory.create())
                .baseUrl("https://d096-2409-4072-683-8f65-e1ad-74cf-1b1b-7782.ngrok-free.app/Maid/mhms/api/")  //Change server URL
//                .client(client)
                .build();

        API api=retrofit.create(API.class);
        Call<CommonResponse> call = api.postMultipleImages("name",list);
        call.enqueue(new Callback<CommonResponse>() {
            @Override
            public void onResponse(Call<CommonResponse> call, Response<CommonResponse> response) {
                CommonResponse model = response.body();
                Toast.makeText(MultiUploadActivity.this, model.getMessage(), Toast.LENGTH_LONG).show();
            }

            @Override
            public void onFailure(Call<CommonResponse> call, Throwable t) {
                Log.e("TAG",t.getMessage());
                Toast.makeText(MultiUploadActivity.this,"onFailure "+ t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

    }
    private MultipartBody.Part prepairFiles(String partName, Uri fileUri){
        File file = new File(fileUri.getPath());
        RequestBody requestBody = RequestBody.create(MediaType.parse("image/*"), file);

        return  MultipartBody.Part.createFormData(partName, file.getName(), requestBody);
    }
}