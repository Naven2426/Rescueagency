package com.example.allapplication.showhidtoolbar;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.transition.Slide;
import androidx.transition.Transition;

import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.DecelerateInterpolator;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.allapplication.R;
import com.makeramen.roundedimageview.RoundedImageView;

import java.util.ArrayList;
import java.util.List;


public class HomeFragment extends Fragment {

    RecyclerView recyclerView;
    ScrolToHideToolbarActivity scrol;
    @SuppressLint("ClickableViewAccessibility")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_home, container, false);
        recyclerView=view.findViewById(R.id.recyclerView);
         scrol=(ScrolToHideToolbarActivity)getActivity();
        recycler(view);
        setRecyclerViewAnimation(recyclerView);
//        recyclerView.setOnTouchListener(new TranslateAnimationUtils(getContext(),scrol.mMainToolbarLayout));
        return view;
    }

    private void setRecyclerViewAnimation(RecyclerView recyclerView){
        final int[] state=new int[1];
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
                state[0]=newState;
            }

            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                if(dy>0 && (state[0]==0 || state[0]==2)){
                    hide();
                }else if(dy<-10){
                    show();
                }
            }
        });
    }
    boolean isFinishAnimation = true;
    private void show(){
        Animation animationDown = AnimationUtils.loadAnimation(getContext(), R.anim.show_down_toolbar);
//        scrol.mMainToolbarLayout.setAnimation(animationDown);
////        scrol.mMainToolbarLayout.setVisibility(View.VISIBLE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            scrol.mMainToolbarLayout.setTransitionVisibility(View.VISIBLE);
        }
    }
    private void animation(){
        Animation animationDown = AnimationUtils.loadAnimation(getContext(), R.anim.show_down_toolbar);

        animationDown.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                scrol.mMainToolbarLayout.setVisibility(View.VISIBLE);
                isFinishAnimation=false;
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                scrol.mMainToolbarLayout.setVisibility(View.GONE);
                isFinishAnimation=true;
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        if(isFinishAnimation){
            scrol.mMainToolbarLayout.startAnimation(animationDown);
        }

        Animation animationUp = AnimationUtils.loadAnimation(getContext(), R.anim.show_up_toolbar);
        animationUp.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                scrol.mMainToolbarLayout.setVisibility(View.VISIBLE);
                isFinishAnimation=false;
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                isFinishAnimation=true;
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        if(isFinishAnimation){
            scrol.mMainToolbarLayout.startAnimation(animationUp);
        }

    }
    private void hide(){
        Animation animation=AnimationUtils.loadAnimation(getContext(), R.anim.show_up_toolbar);
//        scrol.mMainToolbarLayout.setAnimation(animation);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            scrol.mMainToolbarLayout.setTransitionVisibility(View.GONE);
        }

    }

    private void recycler(View view) {

        String text="17% off Lmited Time Deal";
        List<FistGridCardViewRecyclerDataClass> datas=new ArrayList<>();
        datas.add(new FistGridCardViewRecyclerDataClass("https://images.unsplash.com/photo-1489389944381-3471b5b30f04?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8b3BlbiUyMHNvdXJjZXxlbnwwfHwwfHx8MA%3D%3D",text));
        datas.add(new FistGridCardViewRecyclerDataClass("https://images.unsplash.com/photo-1489389944381-3471b5b30f04?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8b3BlbiUyMHNvdXJjZXxlbnwwfHwwfHx8MA%3D%3D",text));
        datas.add(new FistGridCardViewRecyclerDataClass("https://images.unsplash.com/photo-1489389944381-3471b5b30f04?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8b3BlbiUyMHNvdXJjZXxlbnwwfHwwfHx8MA%3D%3D",text));
        datas.add(new FistGridCardViewRecyclerDataClass("https://images.unsplash.com/photo-1489389944381-3471b5b30f04?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8b3BlbiUyMHNvdXJjZXxlbnwwfHwwfHx8MA%3D%3D",text));
        datas.add(new FistGridCardViewRecyclerDataClass("https://images.unsplash.com/photo-1489389944381-3471b5b30f04?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8b3BlbiUyMHNvdXJjZXxlbnwwfHwwfHx8MA%3D%3D",text));
        datas.add(new FistGridCardViewRecyclerDataClass("https://images.unsplash.com/photo-1489389944381-3471b5b30f04?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8b3BlbiUyMHNvdXJjZXxlbnwwfHwwfHx8MA%3D%3D",text));
        datas.add(new FistGridCardViewRecyclerDataClass("https://images.unsplash.com/photo-1489389944381-3471b5b30f04?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8b3BlbiUyMHNvdXJjZXxlbnwwfHwwfHx8MA%3D%3D",text));
        datas.add(new FistGridCardViewRecyclerDataClass("https://images.unsplash.com/photo-1489389944381-3471b5b30f04?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8b3BlbiUyMHNvdXJjZXxlbnwwfHwwfHx8MA%3D%3D",text));
        datas.add(new FistGridCardViewRecyclerDataClass("https://images.unsplash.com/photo-1489389944381-3471b5b30f04?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8b3BlbiUyMHNvdXJjZXxlbnwwfHwwfHx8MA%3D%3D",text));
        datas.add(new FistGridCardViewRecyclerDataClass("https://images.unsplash.com/photo-1489389944381-3471b5b30f04?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8b3BlbiUyMHNvdXJjZXxlbnwwfHwwfHx8MA%3D%3D",text));
        datas.add(new FistGridCardViewRecyclerDataClass("https://images.unsplash.com/photo-1489389944381-3471b5b30f04?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8b3BlbiUyMHNvdXJjZXxlbnwwfHwwfHx8MA%3D%3D",text));
        datas.add(new FistGridCardViewRecyclerDataClass("https://images.unsplash.com/photo-1489389944381-3471b5b30f04?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8b3BlbiUyMHNvdXJjZXxlbnwwfHwwfHx8MA%3D%3D",text));
        datas.add(new FistGridCardViewRecyclerDataClass("https://images.unsplash.com/photo-1489389944381-3471b5b30f04?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8b3BlbiUyMHNvdXJjZXxlbnwwfHwwfHx8MA%3D%3D",text));
        datas.add(new FistGridCardViewRecyclerDataClass("https://images.unsplash.com/photo-1489389944381-3471b5b30f04?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8b3BlbiUyMHNvdXJjZXxlbnwwfHwwfHx8MA%3D%3D",text));
        datas.add(new FistGridCardViewRecyclerDataClass("https://images.unsplash.com/photo-1489389944381-3471b5b30f04?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8b3BlbiUyMHNvdXJjZXxlbnwwfHwwfHx8MA%3D%3D",text));
        datas.add(new FistGridCardViewRecyclerDataClass("https://images.unsplash.com/photo-1489389944381-3471b5b30f04?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8b3BlbiUyMHNvdXJjZXxlbnwwfHwwfHx8MA%3D%3D",text));
        GridLayoutManager grid=new GridLayoutManager(getContext(),2);
        FistGridCardViewRecyclerView adapter=new FistGridCardViewRecyclerView(datas,getContext(),getActivity());
        recyclerView.setLayoutManager(grid);
        recyclerView.setAdapter(adapter);
    }
    public class FistGridCardViewRecyclerDataClass {
        private String image;
        private String text;

        public String getImage() {
            return image;
        }

        public void setImage(String image) {
            this.image = image;
        }

        public String getText() {
            return text;
        }

        public void setText(String text) {
            this.text = text;
        }

        public FistGridCardViewRecyclerDataClass(String image, String text) {
            this.image = image;
            this.text = text;
        }
    }
    public class FistGridCardViewRecyclerView extends RecyclerView.Adapter<FistGridCardViewRecyclerView.MyViewHolder> {
        List<FistGridCardViewRecyclerDataClass> list;
        Context context;
        FragmentActivity activity;
        public FistGridCardViewRecyclerView(List<FistGridCardViewRecyclerDataClass> list, Context context,FragmentActivity activity) {
            this.list = list;
            this.context = context;
            this.activity = activity;
        }

        @NonNull
        @Override
        public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.fist_grid_card_layout_for_home,parent,false);
            return new MyViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
            FistGridCardViewRecyclerDataClass my=list.get(position);
            Glide.with(context).load(my.getImage()).placeholder(R.drawable.image_loading)
                    .error(R.drawable.error_image).into(holder.roundedImageView);
            holder.textView.setText(my.getText());


        }

        @Override
        public int getItemCount() {
            return list.size();
        }

        public class MyViewHolder extends RecyclerView.ViewHolder{
            CardView cardView;
            RoundedImageView roundedImageView;
            TextView textView;
            public MyViewHolder(@NonNull View itemView) {
                super(itemView);
                cardView=itemView.findViewById(R.id.materialCardView);
                roundedImageView=itemView.findViewById(R.id.cardImage);
                textView=itemView.findViewById(R.id.showAmountDetails);
            }
        }
    }
}
