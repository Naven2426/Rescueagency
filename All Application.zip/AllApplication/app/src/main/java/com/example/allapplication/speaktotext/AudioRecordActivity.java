package com.example.allapplication.speaktotext;

import static android.Manifest.permission.RECORD_AUDIO;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.ContextWrapper;
import android.content.pm.PackageManager;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioRouting;
import android.media.AudioTrack;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.allapplication.R;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.net.DatagramPacket;

public class AudioRecordActivity extends AppCompatActivity {
    private TextView startTV, stopTV, playTV, stopplayTV, statusTV;
    // creating a variable for media recorder object class.
    private MediaRecorder mRecorder;
    // creating a variable for mediaplayer class
    private MediaPlayer mPlayer;
    // string variable is created for storing a file name
    private String mFileName = null;
    // constant for storing audio permission
    public static final int REQUEST_AUDIO_PERMISSION_CODE = 1;
    public static final int REQUEST_STORAGE_PERMISSION_CODE = 100;
    //audio recorder class
    boolean isRecording;
    private static final int SAMPLERATE = 44100;
    private static final int REC_CHANNELS = AudioFormat.CHANNEL_IN_MONO;
    private static final int PLAYBACK_CHANNELS = AudioFormat.CHANNEL_OUT_MONO;
    private static final int ENCODING = AudioFormat.ENCODING_PCM_8BIT;
    AudioRecord recorder;
    private static final int MY_CHOSEN_BUFFER_SIZE = 8192;
    Thread recordingThread ;
    byte[] recordedAudioAsBytes;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_audio_record);
        idInit();
        onClickListener();
    }

    private void idInit() {
        statusTV = findViewById(R.id.idTVstatus);
        startTV = findViewById(R.id.btnRecord);
        stopTV = findViewById(R.id.btnStop);
        playTV = findViewById(R.id.btnPlay);
        stopplayTV = findViewById(R.id.btnStopPlay);
        stopTV.setBackgroundColor(getResources().getColor(R.color.gray));
        playTV.setBackgroundColor(getResources().getColor(R.color.gray));
        stopplayTV.setBackgroundColor(getResources().getColor(R.color.gray));
    }

    private void onClickListener() {
        startTV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // start recording method will
                // start the recording of audio.
                startRecording();
            }
        });
        stopTV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // pause Recording method will
                // pause the recording of audio.
                pauseRecording();

            }
        });
        playTV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // play audio method will play
                // the audio which we have recorded
                playAudio();
            }
        });
        stopplayTV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // pause play method will
                // pause the play of audio
                pausePlaying();
            }
        });
    }

    private void startRecording() {
        // check permission method is used to check
        // that the user has granted permission
        // to record and store the audio.
        Log.e("TAG", "microphone permission " + this.getPackageManager().hasSystemFeature(PackageManager.FEATURE_MICROPHONE));
        if (true) {
            // setbackgroundcolor method will change
            // the background color of text view.
            stopTV.setBackgroundColor(getResources().getColor(R.color.purple_200));
            startTV.setBackgroundColor(getResources().getColor(R.color.gray));
            playTV.setBackgroundColor(getResources().getColor(R.color.gray));
            stopplayTV.setBackgroundColor(getResources().getColor(R.color.gray));

            // we are here initializing our filename variable
            // with the path of the recorded audio file.
            mFileName = Environment.getExternalStorageDirectory().getAbsolutePath();
            mFileName += "/ccc.mp3";
            Log.e("TAG", "file path " + mFileName);

            // below method is used to initialize
            // the media recorder class

            // below method is used to set the audio
            // source which we are using a mic.
            mRecorder = new MediaRecorder();
            // audio recorder class
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            recorder = new AudioRecord(MediaRecorder.AudioSource.MIC, SAMPLERATE, REC_CHANNELS,
                    ENCODING, MY_CHOSEN_BUFFER_SIZE);
            recorder.startRecording();
            isRecording = true;
            recordingThread = new Thread(new Runnable() {
                public void run() {
                    Log.i("ABC", "the thread is running");
                    writeAudioToLocalVariable();
                }
            }, "AudioRecorder Thread");
            recordingThread.start();

            mRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);

            // below method is used to set
            // the output format of the audio.
            mRecorder.setOutputFile(getPath());
            mRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);

            // below method is used to set the
            // audio encoder for our recorded audio.
            mRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);

            // below method is used to set the
            // output file location for our recorded audio
            try {
                // below method will prepare
                // our audio recorder class
                mRecorder.prepare();
                mRecorder.start();
                mRecorder.setOnInfoListener(new MediaRecorder.OnInfoListener() {
                    @Override
                    public void onInfo(MediaRecorder mr, int what, int extra) {
                        Log.e("TAG","what "+what);
                        Log.e("TAG","extra "+extra);
                    }
                });

            } catch (Exception e) {
                Log.e("TAG", "prepare() failed "+e.getMessage());
            }
            // start method will start
            // the audio recording.
            statusTV.setText("Recording Started");
        } else {
            // if audio recording permissions are
            // not granted by user below method will
            // ask for runtime permission for mic and storage.
            RequestAudioPermissions();
            RequestStoragePermissions();
        }
    }
    private void writeAudioToLocalVariable() {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        byte[] temporaryChunkOfBytes = new byte[MY_CHOSEN_BUFFER_SIZE];
        int i=0;
        while (isRecording) {
            recorder.read(temporaryChunkOfBytes, 0, MY_CHOSEN_BUFFER_SIZE);
            try {
                i++;
                Log.d("audio bytes"," " + temporaryChunkOfBytes[i]);
                //printBytes(temporaryChunkOfBytes);
                baos.write(temporaryChunkOfBytes, 0, MY_CHOSEN_BUFFER_SIZE);
            } catch (Exception e) {
                Log.i("ABC", "Exception while appending bytes : " + e); // <----- this is not called and that is good.
            }
        }
        recordedAudioAsBytes = baos.toByteArray();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        // this method is called when user will
        // grant the permission for audio recording.
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case REQUEST_AUDIO_PERMISSION_CODE:
                if (grantResults.length > 0) {
                    boolean permissionToRecord = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                    boolean permissionToStore = grantResults[1] == PackageManager.PERMISSION_GRANTED;
                    if (permissionToRecord && permissionToStore) {
                        Toast.makeText(getApplicationContext(), "audio Permission Granted", Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(getApplicationContext(), "audio Permission Denied", Toast.LENGTH_LONG).show();
                    }
                }
                break;
            case REQUEST_STORAGE_PERMISSION_CODE:
                    // If request is cancelled, the result arrays are empty
                    if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                        Toast.makeText(getApplicationContext(), "Storage Permission Granted", Toast.LENGTH_LONG).show();
                        // Permission was granted, proceed with your code
                    } else {
                        // Permission denied, handle accordingly
                        Toast.makeText(this, "Storage Permission denied", Toast.LENGTH_SHORT).show();
                    }
                break;
        }
    }
    private void RequestAudioPermissions() {
        // this method is used to request the
        // permission for audio recording and storage.
        ActivityCompat.requestPermissions(AudioRecordActivity.this, new String[]{RECORD_AUDIO, WRITE_EXTERNAL_STORAGE}, REQUEST_AUDIO_PERMISSION_CODE);
    }
    private void RequestStoragePermissions() {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                    REQUEST_STORAGE_PERMISSION_CODE);
    }

    private String getPath(){
        ContextWrapper contextWrapper=new ContextWrapper(getApplicationContext());
        File directory=contextWrapper.getExternalFilesDir(Environment.DIRECTORY_MUSIC);
        String path=Environment.getExternalStorageDirectory().getAbsolutePath();
        path+="/Documents";
        File f=new File(path);
        File file=new File(f,"my.mp3");
        Log.e("TAG","file path "+file.getPath());
        return file.getPath();
    }

    public void playAudio() {
        stopTV.setBackgroundColor(getResources().getColor(R.color.gray));
        startTV.setBackgroundColor(getResources().getColor(R.color.purple_200));
        playTV.setBackgroundColor(getResources().getColor(R.color.gray));
        stopplayTV.setBackgroundColor(getResources().getColor(R.color.purple_200));

        // for playing our recorded audio
        // we are using media player class.
        mPlayer = new MediaPlayer();
        try {
            // below method is used to set the
            // data source which will be our file name
            // String filePath=FileUtils.getPath(AudioRecordActivity.this, Uri.parse(mFileName));
            mPlayer.setDataSource(getPath());
            // below method will prepare our media player
            mPlayer.prepare();
            // below method will start our media player.
            mPlayer.start();
            statusTV.setText("Recording Started Playing");
        } catch (Exception e) {
            Log.e("TAG", "play audio failed "+e.getMessage());
            e.printStackTrace();
        }
        for (int i=0; i<recordedAudioAsBytes.length; i++) {
            Log.i("BYTESTREAM", "byte[" + i + "] = " + recordedAudioAsBytes[i]);
        }

        // STREAM MODE ACTUALLY WORKS!! (STATIC MODE DOES NOT WORK)
        AudioTrack player = new AudioTrack(AudioManager.STREAM_MUSIC, SAMPLERATE, PLAYBACK_CHANNELS,
                ENCODING, MY_CHOSEN_BUFFER_SIZE, AudioTrack.MODE_STREAM);
        player.play();
        player.write(recordedAudioAsBytes, 0, recordedAudioAsBytes.length);
    }

    public void pauseRecording() {
        stopTV.setBackgroundColor(getResources().getColor(R.color.gray));
        startTV.setBackgroundColor(getResources().getColor(R.color.purple_200));
        playTV.setBackgroundColor(getResources().getColor(R.color.purple_200));
        stopplayTV.setBackgroundColor(getResources().getColor(R.color.purple_200));
        // below method will stop
        // the audio recording.
        if(mRecorder!=null)
        {
            try{
                mRecorder.release();
                mRecorder.stop();
            }catch (Exception e)
            {
                Log.e("TAG","stop method "+e.getMessage());
            }
            // below method will release
            // the media recorder class.
            mRecorder = null;
            statusTV.setText("Recording Stopped");
        }else{
            Toast.makeText(this, "media record null", Toast.LENGTH_SHORT).show();
        }
        if (null != recorder) {
            isRecording = false;
            recorder.stop();
            recorder.release();
            recorder = null;
            recordingThread = null;
        }
    }
    public void pausePlaying() {
        // this method will release the media player
        // class and pause the playing of our recorded audio.
       try{
           mPlayer.release();
           mPlayer.stop();
       }catch (Exception e)
       {
           Log.e("TAG","stop media player "+e.getMessage());
       }
        stopTV.setBackgroundColor(getResources().getColor(R.color.gray));
        startTV.setBackgroundColor(getResources().getColor(R.color.purple_200));
        playTV.setBackgroundColor(getResources().getColor(R.color.purple_200));
        stopplayTV.setBackgroundColor(getResources().getColor(R.color.gray));
        statusTV.setText("Recording Play Stopped");
    }
}