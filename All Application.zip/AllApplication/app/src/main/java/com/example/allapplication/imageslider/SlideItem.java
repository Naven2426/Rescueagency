package com.example.allapplication.imageslider;

public class SlideItem {
    public SlideItem(int image,String showAmount) {
        this.image = image;
        this.showAmount=showAmount;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    private int image;
    private String showAmount;

    public String getShowAmount() {
        return showAmount;
    }

    public void setShowAmount(String showAmount) {
        this.showAmount = showAmount;
    }
}
