package com.example.allapplication.pushnotification;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.allapplication.R;
import com.example.allapplication.databinding.FragmentProfileBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.messaging.FirebaseMessaging;


public class ProfileFragment extends Fragment {

    FragmentProfileBinding binding;
    FirebaseAuth mAuth;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view=inflater.inflate(R.layout.fragment_profile, container, false);
        //code here
        binding=FragmentProfileBinding.inflate(inflater,container,false);
        mAuth=FirebaseAuth.getInstance();
        FCMtoken();
        return binding.getRoot();
    }
    private void FCMtoken(){
        FirebaseMessaging.getInstance().getToken().addOnCompleteListener(new OnCompleteListener<String>() {
            @Override
            public void onComplete(@NonNull Task<String> task) {
                if(task.isSuccessful()){
                    String token = task.getResult();

                    Log.d("FCM_TOKEN","token "+token);
                }else{
                    Log.d("FCM_ERROR_TOKEN",task.getException().getMessage());
                }
            }
        });
    }
//    public void onStart(){
//        super.onStart();
//        if(mAuth.getCurrentUser()==null){
//            Intent intent=new Intent(requireContext(),NotificationActivity.class);
//            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
//            startActivity(intent);
//        }
//    }
//    private void saveToken(String token){
//        String email=mAuth.getCurrentUser().getEmail();
//        User user=new User(email,token);
//        DatabaseReference dbUsers = FirebaseDatabase.getInstance().getReference("users");
//        dbUsers.child(mAuth.getCurrentUser().getUid()).setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {
//            @Override
//            public void onComplete(@androidx.annotation.NonNull Task<Void> task) {
//                Toast.makeText(getContext(), "Token Saved", Toast.LENGTH_SHORT).show();
//            }
//        });
//    }
}