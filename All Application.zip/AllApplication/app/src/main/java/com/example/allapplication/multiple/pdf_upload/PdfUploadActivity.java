package com.example.allapplication.multiple.pdf_upload;

import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

import android.app.Activity;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.GridLayoutManager;

import com.example.allapplication.API;
import com.example.allapplication.R;
import com.example.allapplication.RestClient;
import com.example.allapplication.api.response.CommonResponse;
import com.example.allapplication.databinding.ActivityPdfUploadBinding;
import com.example.allapplication.multiple.RealPathUtil;
import com.example.allapplication.multiple.image.upload.gridview.MultipleImgeUploadRecyclerViewActivity;
import com.example.allapplication.multiple.images.upload.FileUtils;
import com.google.android.gms.common.api.Api;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.regex.Pattern;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class PdfUploadActivity extends AppCompatActivity {

    ActivityPdfUploadBinding binding;
    MultipartBody.Part part;
    private ActivityResultLauncher<Intent> pdfPickerLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK) {
                    Intent data = result.getData();
                    if (data != null) {
                        Uri pdfUri = data.getData();
                        String pdfName = getFileName(pdfUri);
//                        selectedPdfTextView.setText(pdfName);
                        binding.fileName.setText(pdfName);

                        // Do something with the selected PDF file
                    }
                } else {
                    Toast.makeText(PdfUploadActivity.this, "No PDF selected", Toast.LENGTH_SHORT).show();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityPdfUploadBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.uploadButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                api(part,"veera");
//                api("v","v","v","v","v",part,"v","v","v","v");
            }
        });
        binding.select.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Intent pickIntent = new Intent();
//                pickIntent.setType("image/*");
//                pickIntent.setAction(Intent.ACTION_GET_CONTENT);
//                startActivityForResult(pickIntent,1);
                //pdf file chooser
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
//                Intent i = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                intent.setType("application/pdf");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
//                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(intent, 1);

            }
        });

    }
    private void tutorUpload(Uri selectedImage){
        String[] filePathColumn = {MediaStore.Files.FileColumns.DATA};
        Cursor cursor = getContentResolver().query(selectedImage, filePathColumn, null, null, null);
        if (cursor != null) {
            cursor.moveToFirst();
            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
            String filePath = cursor.getString(columnIndex);
            cursor.close();
            File file = new File(filePath);
            binding.fileName.setText(file.getAbsolutePath());
            RequestBody reqFile = RequestBody.create(MediaType.parse("*/*"), file);
            MultipartBody.Part body = MultipartBody.Part.createFormData("profile_image", file.getName(), reqFile);
        }
    }

    private String getPathFromUri(Uri uri) {
        String filePath = null;
        String[] projection = {MediaStore.MediaColumns.DISPLAY_NAME};
        try (Cursor cursor = getContentResolver().query(uri, projection, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                String displayName = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME));
                File file = new File(getExternalFilesDir(null), displayName);
                try (InputStream inputStream = getContentResolver().openInputStream(uri);
                     OutputStream outputStream = new FileOutputStream(file)) {
                    byte[] buffer = new byte[1024];
                    int length;
                    while ((length = inputStream.read(buffer)) > 0) {
                        outputStream.write(buffer, 0, length);
                    }
                    filePath = file.getAbsolutePath();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return filePath;
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        // When an Image is picked
        if (requestCode == 1 && resultCode == RESULT_OK && data != null){
            Uri image = data.getData();
            if(data.getClipData()!=null)
                {
                    for(int i=0;i<data.getClipData().getItemCount();i++){

                        Uri imageurl = data.getClipData().getItemAt(i).getUri();
//                    tutorUpload(image);

                        String path= getPathFromUri(imageurl);
                        File file = new File(path);
                        Log.d("file",file.getName()+" "+file.getPath());
                        binding.fileName.setText(file.getName()+" "+file.getPath());
                    RequestBody requestBody = RequestBody.create(MediaType.parse("*/*"), file);
                        part= MultipartBody.Part.createFormData("file", file.getName(), requestBody);
                    }


                }else{
                    Toast.makeText(PdfUploadActivity.this, "No PDF selected", Toast.LENGTH_SHORT).show();
                }
            }

    }
    public String getFilePathFromUri(Uri uri) {
        if (uri == null) {
            return null;
        }

        if (DocumentsContract.isDocumentUri(this, uri)) {
            // ExternalStorageProvider
            if (isExternalStorageDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                final String type = split[0];

                if ("primary".equalsIgnoreCase(type)) {
                    return Environment.getExternalStorageDirectory() + "/" + split[1];
                }
                // TODO handle non-primary volumes
            }
            // DownloadsProvider
            else if (isDownloadsDocument(uri)) {
                final String id = DocumentsContract.getDocumentId(uri);
                if (id.startsWith("raw:")) {
                    return id.substring(4);
                }
                try {
                    final Uri contentUri = ContentUris.withAppendedId(
                            Uri.parse("content://downloads/public_downloads"), Long.valueOf(id));
                    return getDataColumn(this, contentUri, null, null);
                } catch (NumberFormatException e) {
                    Log.e("File Path Error", "Number format exception: " + e.getMessage());
                }
            }
            // MediaProvider
            else if (isMediaDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                final String type = split[0];

                Uri contentUri = null;
                if ("image".equals(type)) {
                    contentUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                } else if ("video".equals(type)) {
                    contentUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                } else if ("audio".equals(type)) {
                    contentUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                }else if("pdf".equals(type)){
                    contentUri = MediaStore.Files.getContentUri("external");
                }

                final String selection = "_id=?";
                final String[] selectionArgs = new String[] { split[1] };

                return getDataColumn(this, contentUri, selection, selectionArgs);
            }
        }
        // MediaStore (and general)
        else if ("content".equalsIgnoreCase(uri.getScheme())) {
            return getDataColumn(this, uri, null, null);
        }
        // File
        else if ("file".equalsIgnoreCase(uri.getScheme())) {
            return uri.getPath();
        }

        return null;
    }

    public String getDataColumn(Context context, Uri uri, String selection, String[] selectionArgs) {
        Cursor cursor = null;
        final String column = "_data";
        final String[] projection = { column };

        try {
            cursor = context.getContentResolver().query(uri, projection, selection, selectionArgs,
                    null);
            if (cursor != null && cursor.moveToFirst()) {
                final int index = cursor.getColumnIndexOrThrow(column);
                return cursor.getString(index);
            }
        } catch (Exception e) {
            Log.e("File Path Error", "Error retrieving data from URI: " + e.getMessage());
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return null;
    }

    public boolean isExternalStorageDocument(Uri uri) {
        return "com.android.externalstorage.documents".equals(uri.getAuthority());
    }

    public boolean isDownloadsDocument(Uri uri) {
        return "com.android.providers.downloads.documents".equals(uri.getAuthority());
    }

    public boolean isMediaDocument(Uri uri) {
        return "com.android.providers.media.documents".equals(uri.getAuthority());
    }

    private String getFileName(Uri uri) {
        String result = null;
        if (uri.getScheme().equals("content")) {
            try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    int columnIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    if (columnIndex != -1) {
                        result = cursor.getString(columnIndex);
                    }
                }
            }
        }
        if (result == null) {
            result = uri.getLastPathSegment();
        }
        return result;
    }
    public String getPDFPath2(Uri uri){

        final String id = DocumentsContract.getDocumentId(uri);
        final Uri contentUri = ContentUris.withAppendedId(
                Uri.parse("content://downloads/public_downloads"), Long.valueOf(id));

        String[] projection = { MediaStore.Images.Media.DATA };
        Cursor cursor = getContentResolver().query(contentUri, projection, null, null, null);
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        return cursor.getString(column_index);
    }
    public String getPDFPath(Uri uri) {
        String[] projection = { MediaStore.Files.FileColumns.DATA };
        Cursor cursor = getContentResolver().query(uri, projection, null, null, null);
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATA);
        cursor.moveToFirst();
        return cursor.getString(column_index);
    }

    private void api(MultipartBody.Part part , String email){
        Retrofit retrofit = new Retrofit.Builder()
                .addConverterFactory(GsonConverterFactory.create())
                .baseUrl("https://4755-2409-4072-484-7f38-58c8-92ee-329d-1dc4.ngrok-free.app/")  //Change server URL
//                .client(client)
                .build();
        API api = retrofit.create(API.class);
        Call<CommonResponse> responseCall= api.pdfUpload(email,part);
        responseCall.enqueue(new Callback<CommonResponse>() {
            @Override
            public void onResponse(Call<CommonResponse> call, Response<CommonResponse> response) {
                if(response.isSuccessful()){
                    Log.d("response",response.body().getMessage());
                    Toast.makeText(PdfUploadActivity.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                }else{
                    Log.d("response",""+response.isSuccessful());
                    Toast.makeText(PdfUploadActivity.this, ""+response.isSuccessful(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<CommonResponse> call, Throwable t) {
                Log.d("error",t.getMessage());
                Toast.makeText(PdfUploadActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
    private void api(String agencyName, String teamType, String mobile, String address, String totalMember,
                     MultipartBody.Part part , String email, String userName, String password, String userType){

        Retrofit retrofit = new Retrofit.Builder()
                .addConverterFactory(GsonConverterFactory.create())
                .baseUrl("https://7359-2409-4072-484-7f38-6dfd-a051-8e3e-44f3.ngrok-free.app/")  //Change server URL
//                .client(client)
                .build();
        API api = retrofit.create(API.class);
        Call<CommonResponse> responseCall= api.agencyRegister(agencyName,teamType,mobile,address,totalMember,part,email,userName,password,userType);
        responseCall.enqueue(new Callback<CommonResponse>() {
            @Override
            public void onResponse(Call<CommonResponse> call, Response<CommonResponse> response) {
                if(response.isSuccessful()){
                    CommonResponse signUpResponse=response.body();
                    if(signUpResponse.getStatus()==200){
                        Toast.makeText(PdfUploadActivity.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();

                    }else{
                        Toast.makeText(PdfUploadActivity.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onFailure(Call<CommonResponse> call, Throwable t) {
                Toast.makeText(PdfUploadActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();
                Log.d("error",t.getMessage());
            }
        });
    }

}