package com.example.allapplication;

import android.content.Context;
import android.content.pm.PackageManager;

import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;

public class Permission {
    public static final int STORAGE_PERMISSION = 1;
    public static final int CAMERA_PERMISSION = 2;
    public static final int LOCATION_PERMISSION = 3;
    public static final int MICROPHONE_PERMISSION = 4;
    public static final int POST_NOTIFICATION_PERMISSION = 5;
    public static final int PERMISSION_GRANTED = PackageManager.PERMISSION_GRANTED;

    public static boolean isPermissionGranted(Context context,String permission) {
        return (ActivityCompat.checkSelfPermission(context,permission) == PERMISSION_GRANTED);
    }

    public static void requestPermission(FragmentActivity activity, String permission,int requestCode) {
        ActivityCompat.requestPermissions(activity,new String[]{permission},requestCode);
    }

}
