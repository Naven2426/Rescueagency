package com.example.allapplication.chatapp.mychat;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import com.example.allapplication.R;

import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;

import java.net.URI;
import java.net.URISyntaxException;

public class WebSocketRoomActivity extends AppCompatActivity {

    private WebSocketClient webSocketClient;
    private EditText roomInput;
    private EditText messageInput;
    private TextView chatOutput;
    private Button joinButton;
    private Button sendButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_socket_room);
        roomInput = findViewById(R.id.roomInput);
        messageInput = findViewById(R.id.messageInput);
        chatOutput = findViewById(R.id.chatOutput);
        joinButton = findViewById(R.id.joinButton);
        sendButton = findViewById(R.id.sendButton);
        joinButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String roomId = roomInput.getText().toString();
                connectWebSocket(roomId);
            }
        });

        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String message = messageInput.getText().toString();
                if (webSocketClient != null && webSocketClient.isOpen()) {
                    webSocketClient.send("{\"type\":\"message\", \"message\":\"" + message + "\"}");
                }
            }
        });
    }
    private void connectWebSocket(final String roomId) {
        URI uri;
        try {
            uri = new URI("https://96b0-2409-4072-80e-c767-4fd-45b5-6e1a-7ce1.ngrok-free.app");
        } catch (URISyntaxException e) {
            e.printStackTrace();
            return;
        }

        webSocketClient = new WebSocketClient(uri) {
            @Override
            public void onOpen(ServerHandshake handshakedata) {
                webSocketClient.send("{\"type\":\"join\", \"roomId\":\"" + roomId + "\"}");
            }

            @Override
            public void onMessage(String message) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        chatOutput.append("Received: " + message + "\n");
                    }
                });
            }

            @Override
            public void onClose(int code, String reason, boolean remote) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        chatOutput.append("Disconnected: " + reason + "\n");
                    }
                });
            }

            @Override
            public void onError(Exception ex) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        chatOutput.append("Error: " + ex.getMessage() + "\n");
                    }
                });
            }
        };
        webSocketClient.connect();
    }
}