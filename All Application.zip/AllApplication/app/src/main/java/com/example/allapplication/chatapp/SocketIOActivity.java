package com.example.allapplication.chatapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import com.example.allapplication.R;
import com.example.allapplication.databinding.ActivitySocketIoactivityBinding;

import org.json.JSONException;
import org.json.JSONObject;

import io.socket.client.IO;
import io.socket.client.Socket;
import io.socket.emitter.Emitter;

public class SocketIOActivity extends AppCompatActivity {
    private Socket mSocket;
    private EditText messageInput;
    private TextView chatBox;
    private EditText roomInput;
    private EditText usernameInput;
    private Button joinButton;
    private Button sendButton;
    ActivitySocketIoactivityBinding binding;

    {
        try {
            mSocket = IO.socket("https://6321-2409-4072-80e-c767-9da-c714-d0cf-d9a.ngrok-free.app"); // Use the IP of your server if not using the emulator
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding         = ActivitySocketIoactivityBinding.inflate(getLayoutInflater());
        setContentView(R.layout.activity_socket_ioactivity);
        messageInput    = findViewById(R.id.messageInput);
        chatBox         = findViewById(R.id.chatBox);
        roomInput       = findViewById(R.id.roomInput);
        usernameInput   = findViewById(R.id.usernameInput);
        joinButton      = findViewById(R.id.joinButton);
        sendButton      = findViewById(R.id.sendButton);

        joinButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameInput.getText().toString();
                String room = roomInput.getText().toString();
                mSocket.emit("joinRoom", createUserRoomJson(username, room));
            }
        });
        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String message  = messageInput.getText().toString();
                String room     = roomInput.getText().toString();
                String username = usernameInput.getText().toString();
                mSocket.emit("sendMessage", createMessageJson(message, room, username));
                messageInput.setText("");
            }
        });

        mSocket.on("message", new Emitter.Listener() {
            @Override
            public void call(final Object... args) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        JSONObject data = (JSONObject) args[0];
                        try {
                            String user = data.getString("user");
                            String message = data.getString("text");
                            chatBox.append(user + ": " + message + "\n");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                });
            }
        });
        mSocket.connect();

    }
    private JSONObject createUserRoomJson(String username, String room) {
        JSONObject json = new JSONObject();
        try {
            json.put("username", username);
            json.put("room", room);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return json;
    }

    private JSONObject createMessageJson(String message, String room, String username) {
        JSONObject json = new JSONObject();
        try {
            json.put("message", message);
            json.put("room", room);
            json.put("username", username);
            json.put("isSend",true);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return json;
    }

}