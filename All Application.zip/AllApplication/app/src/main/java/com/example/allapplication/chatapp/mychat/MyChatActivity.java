package com.example.allapplication.chatapp.mychat;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.allapplication.RestClient;
import com.example.allapplication.api.response.chat.ChatResponse;
import com.example.allapplication.databinding.ActivityMyChatBinding;
import com.example.allapplication.databinding.ItemChatLeftBinding;
import com.example.allapplication.databinding.ItemChatRightBinding;

import org.json.JSONException;
import org.json.JSONObject;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

import io.socket.client.IO;
import io.socket.client.Socket;
import io.socket.emitter.Emitter;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MyChatActivity extends AppCompatActivity {

    private ActivityMyChatBinding binding;
    private RecyclerAdapter adapter;
    private Socket socket;
    private List<ChatModel> chatList = new ArrayList<>();
    String number;
    ChatModel chat;
    String userName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMyChatBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        userName=getIntent().getStringExtra("name");
        number=getIntent().getStringExtra("number");
        binding.number.setText(number);
        adapter = new RecyclerAdapter();
        retrofit2.Call<ChatResponse> responseCall = RestClient.getInstance().getApi().getChat("1234");
        responseCall.enqueue(new Callback<ChatResponse>() {
            @Override
            public void onResponse(Call<ChatResponse> call, Response<ChatResponse> response) {
                if (response.isSuccessful()) {
                    binding.recyclerView.setAdapter(adapter);
                    for(int i=0;i<response.body().getResult().size();i++)
                    {
                        ChatResponse.Results result=response.body().getResult().get(i);
                        adapter.setData(new ChatModel(result.getUser_name(),result.getMessage(),result.getMobile()),binding);
                    }
                    binding.recyclerView.setLayoutManager(new LinearLayoutManager(MyChatActivity.this));
                }
            }

            @Override
            public void onFailure(Call<ChatResponse> call, Throwable t) {

            }
        });
//        adapter.setData(new ChatModel());


        try {
            socket = IO.socket(RestClient.API_BASE_URL); // Replace with your server URL
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
        socket.emit("joinRoom",createUserRoomJson(userName,"1234"));
        socket.on("message", new Emitter.Listener() {
            @Override
            public void call(Object... args) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        JSONObject data = (JSONObject) args[0];https://6321-2409-4072-80e-c767-9da-c714-d0cf-d9a.ngrok-free.app
                        try {
                            String userName = data.getString("user");
                            String message = data.getString("text");
                            String number= data.getString("number");
                             chat = new ChatModel(userName, message, number);
//                            chatList.add(chat);
                            adapter.setData(chat,binding);
                            binding.recyclerView.scrollToPosition(chatList.size() - 1);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                });
            }
        });
        socket.connect();
        binding.sendButton.setOnClickListener(v -> {
            String message = binding.messageInput.getText().toString();
            if (!message.isEmpty()) {
                JSONObject data = new JSONObject();
                try {
                    number=binding.number.getText().toString();
                    data.put("username", userName);
                    data.put("message", message);
                    data.put("number", number);
                    data.put("room", "1234");
                    socket.emit("sendMessage", data);
                    number=null;
//                    chatList.add(new ChatModel(userName, message, 0, "SEND"));
//                    adapter.setData(new ChatModel(userName, message, 0, "SEND"));
                    binding.recyclerView.scrollToPosition(chatList.size() - 1);
                    binding.messageInput.setText("");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });

    }
    private JSONObject createMessageJson(String message, String room, String username) {
        JSONObject json = new JSONObject();
        try {
            json.put("message", message);
            json.put("room", room);
            json.put("countUnread", 0);
            json.put("username", username);
            json.put("type", "SEND");

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return json;
    }
    private JSONObject createUserRoomJson(String username, String room) {
        JSONObject json = new JSONObject();
        try {
            json.put("username", username);
            json.put("room", room);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return json;
    }
    public static class ChatModel {
        private String userName;
        private String message;
        private String number; // "SEND" or "RECEIVE"

        // Constructors, getters, and setters

        public ChatModel(String userName, String message, String number) {
            this.userName = userName;
            this.message = message;
            this.number=number;
        }

        public String getNumber() {
            return number;
        }

        public void setNumber(String number) {
            this.number = number;
        }

        public String getUserName() {
            return userName;
        }

        public void setUserName(String userName) {
            this.userName = userName;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }


    }
    static class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.ViewHolder> {
        ActivityMyChatBinding binding;
        private static final int LEFT_VIEW = 0;
        private static final int RIGHT_VIEW = 1;

        private final List<ChatModel> listOfChat = new ArrayList<>();

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LayoutInflater inflater = LayoutInflater.from(parent.getContext());
            if (viewType == LEFT_VIEW) {
                ItemChatLeftBinding binding = ItemChatLeftBinding.inflate(inflater, parent, false);
                return new LeftViewHolder(binding);
            } else {
                ItemChatRightBinding binding = ItemChatRightBinding.inflate(inflater, parent, false);
                return new RightViewHolder(binding);
            }
        }

        @Override
        public int getItemCount() {
            return listOfChat.size();
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            ChatModel chat = listOfChat.get(position);
            if (chat.getNumber().equals(binding.number.getText().toString())) {
                ((RightViewHolder) holder).bind(chat);
            } else {
                ((LeftViewHolder) holder).bind(chat);
            }
        }

        @Override
        public int getItemViewType(int position) {
            ChatModel chat = listOfChat.get(position);
            return chat.getNumber().equals(binding.number.getText().toString()) ? RIGHT_VIEW : LEFT_VIEW;
        }

        @SuppressLint("NotifyDataSetChanged")
        public void setData(ChatModel list,ActivityMyChatBinding binding) {
//            listOfChat.clear();
            listOfChat.add(list);
            notifyDataSetChanged();

            this.binding=binding;
        }

        static class ViewHolder extends RecyclerView.ViewHolder {
            public ViewHolder(@NonNull View itemView) {
                super(itemView);
            }
        }

       static class LeftViewHolder extends ViewHolder {
            private final ItemChatLeftBinding binding;

            public LeftViewHolder(ItemChatLeftBinding binding) {
                super(binding.getRoot());
                this.binding = binding;
            }

            public void bind(ChatModel chat) {
                binding.itemUsername.setText(chat.getUserName());
                binding.itemMessage.setText(chat.getMessage());
            }
        }

        static class RightViewHolder extends ViewHolder {
            private final ItemChatRightBinding binding;

            public RightViewHolder(ItemChatRightBinding binding) {
                super(binding.getRoot());
                this.binding = binding;
            }

            public void bind(ChatModel chat) {
                binding.itemMessage.setText(chat.getMessage());
            }
        }
    }


}