package com.example.allapplication.chatapp.kotline

import android.os.Bundle
import android.util.Log
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.allapplication.R
import com.example.allapplication.databinding.ActivityChatKotilnBinding
import io.socket.client.IO
import io.socket.client.Socket


class ChatKotilnActivity : AppCompatActivity() {
    private lateinit var binding: ActivityChatKotilnBinding
    var counter:Int=0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityChatKotilnBinding.inflate(layoutInflater)
        setContentView(binding.root)
        enableEdgeToEdge()

        SocketHandler.setSocket()
        val mSocket = SocketHandler.getSocket()
        mSocket.connect()

        binding.send.setOnClickListener {
            mSocket.emit("counter")
            binding.tvMessage.text = counter.toString()
        }
        mSocket.on("counter") { args ->
            if (args[0] != null) {
               val counter = args[0] as Int

                runOnUiThread {
                    binding.tvMessage.text = counter.toString()
                }
            }
        }
    }

}