package com.example.allapplication.api.response.map.nearbyapi;

public class Opening_hours {
    private boolean open_now;

    public void setOpen_now(boolean open_now) {
        this.open_now = open_now;
    }
    public boolean getOpen_now() {
        return open_now;
    }
}
