package com.example.allapplication.googlemap;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.signature.AndroidResourceSignature;
import com.directions.route.AbstractRouting;
import com.directions.route.Route;
import com.directions.route.RouteException;
import com.directions.route.Routing;
import com.directions.route.RoutingListener;
import com.example.allapplication.API;
import com.example.allapplication.R;
import com.example.allapplication.RestClient;
import com.example.allapplication.api.response.GoogleMapResponse;
import com.example.allapplication.api.response.map.ditance.DitanceAndDurationRoot;
import com.example.allapplication.api.response.map.ditance.Elements;
import com.example.allapplication.api.response.map.nearbyapi.NearbyRoot;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.Dot;
import com.google.android.gms.maps.model.Gap;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.example.allapplication.databinding.ActivityMapsBinding;
import com.google.android.gms.maps.model.PatternItem;
import com.google.android.gms.maps.model.Polygon;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.libraries.places.api.Places;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.android.material.snackbar.Snackbar;
import com.jakewharton.retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;

import org.w3c.dom.Text;

import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;

import java.io.IOException;
import java.lang.invoke.CallSite;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import io.reactivex.schedulers.Schedulers;
//import io.reactivex.rxjava3.schedulers.Schedulers;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback,
        GoogleApiClient.OnConnectionFailedListener ,RoutingListener,Callback<DitanceAndDurationRoot>{
    private GoogleMap mMap;
    private ActivityMapsBinding binding;
    private TextView tvShowLocation;
//    private final String API_KEY = "AIzaSyBdqeQxBFcVHkjkskINoPu8K21VAzHh94s";
    private final String MY_API = "AIzaSyB99Ol78n6mm0nKWURPaqrLPm2jtjYFEKw";
    private Location location;
    private Polyline polyline;
    private LatLng start=null;
    private LatLng end=null;
    private Location myLocation=null;
    private ImageButton reload;
    private ArrayList<LatLng> a;
    private ArrayList<MarkerOptions> marker;
//    BottomNavigationView bottomNavView;;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMapsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        tvShowLocation = findViewById(R.id.showLocation);
        reload = findViewById(R.id.load);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        reload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(myLocation!=null){
                     a=new ArrayList();

                    start=new LatLng(myLocation.getLatitude(),myLocation.getLongitude());

                    LatLng guindy=new LatLng(13.010236,80.215652);

                    LatLng perungalathur=new LatLng(12.904759,80.089081);

                    a.add(guindy);
                    a.add(perungalathur);

                    findNearbyAgency(start,a);
                }else Toast.makeText(MapsActivity.this, "mylocation null", Toast.LENGTH_SHORT).show();
            }
        });

    }
    private void bottomSheet()
    {
        BottomSheetDialog bottom=new BottomSheetDialog(this);
//        bottom.setContentView(R.layout.bottom_sheet_layout_for_maps_activity);
        @SuppressLint("ResourceType")
//        View view=findViewById(R.layout.bottom_sheet_layout_for_maps_activity);
        View view=LayoutInflater.from(this).inflate(R.layout.bottom_sheet_layout_for_maps_activity,null);
        bottom.setContentView(view);
        bottom.show();
        bottom.setDismissWithAnimation(true);
        TextView textView=bottom.findViewById(R.id.text);
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MapsActivity.this, "text", Toast.LENGTH_SHORT).show();
            }
        });



    }

    private Location getCurrentLocation() {
        int permissionCheck = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION);
        if (permissionCheck != PackageManager.PERMISSION_GRANTED) return null;

        LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        Location location = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);

        return location;
    }

    private String getCurrentCoordinate() {
        location = getCurrentLocation();
        if (location == null) return "";
        return location.getLatitude() + "," + location.getLongitude();
    }

    private void getDistanceInfo(LatLng origin,LatLng destination) {

        Map<String, String> myMapQuery = new HashMap<>();
        myMapQuery.put("key", MY_API);
        myMapQuery.put("origins", origin.latitude + "," + origin.longitude);
        myMapQuery.put("destinations", destination.latitude + "," + destination.longitude);
        myMapQuery.put("mode", "Driving");
        API client = RestClient.getInstance().getRetrofit().create(API.class);

        Call<GoogleMapResponse> call = client.getDistanceInfo1(myMapQuery);
        call.enqueue(new Callback<GoogleMapResponse>() {
            @Override
            public void onResponse(Call<GoogleMapResponse> call, Response<GoogleMapResponse> response) {
                if (response.body() != null
                       /* &&
                        response.body().getRows() != null &&
                        response.body().getRows().size() > 0 &&
                        response.body().getRows().get(0) != null &&
                        response.body().getRows().get(0).getElements() != null &&
                        response.body().getRows().get(0).getElements().size() > 0 &&
                        response.body().getRows().get(0).getElements().get(0) != null &&
                        response.body().getRows().get(0).getElements().get(0).getDistance() != null &&
                        response.body().getRows().get(0).getElements().get(0).getDuration() != null */
                ) {
                    GoogleMapResponse.Row.Element element = response.body().getRows().get(0).getElements().get(0);
                    String address = response.body().getDestination_addresses().get(0);
                    String duration=element.getDuration().getText()+" "+element.getDistance().getText();
                    showTravelDistance(duration);
                    showTravelDistance(element.getDistance().getText() + "\n" + element.getDuration().getText());
                    Log.e("TAG", "distance : " + element.getDistance().getText() + "\n "
                            + element.getDuration().getText());
                    Toast.makeText(MapsActivity.this, "success " + element.getDistance().getText()
                            + "\n" + element.getDuration().getText(), Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MapsActivity.this, "else part " + response.body().getStatus(), Toast.LENGTH_SHORT).show();
                    Log.d("MainActivity", "onFailure : " + response.body().getStatus());
                }
            }

            @Override
            public void onFailure(Call<GoogleMapResponse> call, Throwable t) {
                Toast.makeText(MapsActivity.this, "onFailure " + t.getMessage(), Toast.LENGTH_SHORT).show();
                Log.d("MainActivity", "onFailure : " + t.getMessage());
            }
        });
    }

    private void showTravelDistance(String travelInfo) {
        tvShowLocation.setText(travelInfo);
    }

    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        mMap.setMyLocationEnabled(true);
        mMap.setOnMyLocationButtonClickListener(new GoogleMap.OnMyLocationButtonClickListener() {
            @Override
            public boolean onMyLocationButtonClick() {
                Toast.makeText(MapsActivity.this, "my location button " , Toast.LENGTH_SHORT).show();

                return false;
            }
        });
        myLocation=mMap.getMyLocation();
        mMap.setOnMyLocationChangeListener(new GoogleMap.OnMyLocationChangeListener() {
            @Override
            public void onMyLocationChange(Location location) {
                myLocation=location;
//                LatLng ltlng=new LatLng(location.getLatitude(),location.getLongitude());
//                CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(ltlng, 16f);
//                mMap.animateCamera(cameraUpdate);
            }
        });
        mMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(@NonNull Marker marker) {
                end=new LatLng(marker.getPosition().latitude,marker.getPosition().longitude);
                bottomSheet();
                Findroutes(start,end);
                Toast.makeText(MapsActivity.this, marker.getTitle(), Toast.LENGTH_SHORT).show();
//                mMap.clear();
                return false;
            }
        });
//        mMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
//            @Override
//            public void onMapClick(@NonNull LatLng latLng) {
//                end=latLng;
//                start=new LatLng(myLocation.getLatitude(),myLocation.getLongitude());
//                Findroutes(start,end);
//            }
//        });


//        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(-23.684, 133.903), 4));
    }
    private double getDouble(String str){
        StringBuilder s=new StringBuilder();
        if(!str.isEmpty())
        {
            for(int j = 0; j < str.length(); j++)
            {
                char ch = str.charAt(j);
                if (!(ch==' ' ) && !((ch<91 && ch>64)||(ch<123 && ch>96)))
                {
                    s.append(ch);
                }
            }
        }
        else{
            Toast.makeText(this, "latlong is empty", Toast.LENGTH_SHORT).show();
        }
//        s.append("d");
        return Double.parseDouble(s.toString());
    }
    List<String> km;
    List<String> min;
    private void findNearbyAgency(LatLng myLocation,List<LatLng> nearBy)
    {
        km=new ArrayList<>();
        min=new ArrayList<>();
        try {
            for (int i = 0; i < nearBy.size(); i++) {
                distance(myLocation,nearBy.get(i));

                Thread.sleep(1000);
            }
//            Toast.makeText(MapsActivity.this,"km list size "+km.size(),Toast.LENGTH_SHORT).show();

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(MapsActivity.this,"Exception: "+e.getMessage(),Toast.LENGTH_SHORT).show();

        }

    }
    String[] s=new String[5];
    int i=0;
    private void distance(LatLng start,LatLng end)
    {
        Map<String, String> myMapQuery = new HashMap<>();
        myMapQuery.put("key", MY_API);
        myMapQuery.put("origins", start.latitude + "," + start.longitude);
        myMapQuery.put("destinations", end.latitude + "," + end.longitude);
        myMapQuery.put("mode", "Driving");
        API client = RestClient.getInstance().getRetrofit().create(API.class);
        Call<DitanceAndDurationRoot> call = client.getDistanceInfo(myMapQuery);
        call.enqueue(this);
    }
    @Override
    public void onResponse(Call<DitanceAndDurationRoot> call, Response<DitanceAndDurationRoot> response) {
        if (response.body() != null) {
            Elements element = response.body().getRows().get(0).getElements().get(0);
//                    String address = response.body().getDestinationAddresses().get(0);
            String duration=element.getDuration().getText();
            String distance=element.getDistance().getText();
            km.add(distance);
            if(a.size()==km.size())
            {
                Toast.makeText(MapsActivity.this,"location marked ",Toast.LENGTH_SHORT).show();
                for(int i=0;i<km.size();i++)
                {
                    if(1000>getDouble(distance)){
                        String markerName=Integer.toHexString(System.identityHashCode(a.get(i)));
                        MarkerOptions marker = new MarkerOptions().position(a.get(i)).title(markerName);
                        mMap.addMarker(marker);
//                                Toast.makeText(MapsActivity.this,"marked",Toast.LENGTH_SHORT).show();
                    }
                }
            }

        } else {
            Toast.makeText(MapsActivity.this, "else part " + response.body().getStatus(), Toast.LENGTH_SHORT).show();
            Log.d("MainActivity", "else part : " + response.body().getStatus());
        }
    }

    @Override
    public void onFailure(Call<DitanceAndDurationRoot> call, Throwable t) {
        Toast.makeText(MapsActivity.this, "onFailure " + t.getMessage(), Toast.LENGTH_SHORT).show();
        Log.d("MainActivity", "onFailure : " + t.getMessage());
    }
    List<Polyline> polylines=null;
    public void Findroutes(LatLng Start, LatLng End)
    {
        if(Start==null || End==null) {
            Toast.makeText(MapsActivity.this,"Unable to get location", Toast.LENGTH_LONG).show();
        }
        else
        {
            Routing routing = new Routing.Builder()
                    .travelMode(AbstractRouting.TravelMode.DRIVING)
                    .withListener(this)
                    .alternativeRoutes(true)
                    .waypoints(Start, End)
                    .key(MY_API)  //also define your api key here.
                    .build();
            routing.execute();

        }
    }
    @Override
    public void onRoutingFailure(RouteException e) {
        View parentLayout = findViewById(android.R.id.content);
        Snackbar snackbar = Snackbar.make(parentLayout, "connection "+e.toString(), Snackbar.LENGTH_LONG);
        snackbar.show();
    }

    @Override
    public void onRoutingStart() {
        Toast.makeText(MapsActivity.this,"my Finding Route...",Toast.LENGTH_LONG).show();

    }

    @Override
    public void onRoutingSuccess(ArrayList<Route> arrayList, int j) {

        if (polyline != null) {
            polyline.remove();
        }

        PolylineOptions polyOptions = new PolylineOptions();
        LatLng polylineStartLatLng = null;
        LatLng polylineEndLatLng = null;

        polylines = new ArrayList<>();
        //add route(s) to the map using polyline
        for (int i = 0; i < arrayList.size(); i++) {

            if (i == j) {
                polyOptions.color(Color.BLUE);
                polyOptions.width(7);
                polyOptions.addAll(arrayList.get(j).getPoints());
                 polyline = mMap.addPolyline(polyOptions);
                polylineStartLatLng = polyline.getPoints().get(0);
                int k = polyline.getPoints().size();
                polylineEndLatLng = polyline.getPoints().get(k - 1);
//                polylines.add(polyline);
            } else {

            }

        }
        mMap.setTrafficEnabled(true);

        MarkerOptions startMarker = new MarkerOptions();
        startMarker.position(polylineStartLatLng);
        startMarker.title("My Location");
        mMap.addMarker(startMarker);
        //Add Marker on route ending position
        MarkerOptions endMarker = new MarkerOptions();
        endMarker.position(polylineEndLatLng);
        endMarker.title("Destination");
        mMap.addMarker(endMarker);
    }

    @Override
    public void onRoutingCancelled() {
        Findroutes(start,end);
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
        Findroutes(start,end);
    }



}