package com.example.allapplication.api.response.map.nearbyapi;

import java.util.List;

public class Results {
    private String business_status;
    private Geometry geometry;
    private String icon;
    private String icon_background_color;
    private String icon_mask_base_uri;
    private String name;
    private Opening_hours opening_hours;
    private List<Photos> photos;
    private String place_id;
    private Plus_code plus_code;
    private int price_level;
    private int rating;
    private String reference;
    private String scope;
    private List<String> types;
    private int user_ratings_total;
    private String vicinity;

    public void setBusiness_status(String business_status) {
        this.business_status = business_status;
    }
    public String getBusiness_status() {
        return business_status;
    }
    public void setGeometry(Geometry geometry) {
        this.geometry = geometry;
    }
    public Geometry getGeometry() {
        return geometry;
    }
    public void setIcon(String icon) {
        this.icon = icon;
    }
    public String getIcon() {
        return icon;
    }
    public void setIcon_background_color(String icon_background_color) {
        this.icon_background_color = icon_background_color;
    }
    public String getIcon_background_color() {
        return icon_background_color;
    }
    public void setIcon_mask_base_uri(String icon_mask_base_uri) {
        this.icon_mask_base_uri = icon_mask_base_uri;
    }
    public String getIcon_mask_base_uri() {
        return icon_mask_base_uri;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getName() {
        return name;
    }
    public void setOpening_hours(Opening_hours opening_hours) {
        this.opening_hours = opening_hours;
    }
    public Opening_hours getOpening_hours() {
        return opening_hours;
    }
    public void setPhotos(List<Photos> photos) {
        this.photos = photos;
    }
    public List<Photos> getPhotos() {
        return photos;
    }
    public void setPlace_id(String place_id) {
        this.place_id = place_id;
    }
    public String getPlace_id() {
        return place_id;
    }
    public void setPlus_code(Plus_code plus_code) {
        this.plus_code = plus_code;
    }
    public Plus_code getPlus_code() {
        return plus_code;
    }
    public void setPrice_level(int price_level) {
        this.price_level = price_level;
    }
    public int getPrice_level() {
        return price_level;
    }
    public void setRating(int rating) {
        this.rating = rating;
    }
    public int getRating() {
        return rating;
    }
    public void setReference(String reference) {
        this.reference = reference;
    }
    public String getReference() {
        return reference;
    }
    public void setScope(String scope) {
        this.scope = scope;
    }
    public String getScope() {
        return scope;
    }
    public void setTypes(List<String> types) {
        this.types = types;
    }
    public List<String> getTypes() {
        return types;
    }
    public void setUser_ratings_total(int user_ratings_total) {
        this.user_ratings_total = user_ratings_total;
    }
    public int getUser_ratings_total() {
        return user_ratings_total;
    }
    public void setVicinity(String vicinity) {
        this.vicinity = vicinity;
    }
    public String getVicinity() {
        return vicinity;
    }
}
