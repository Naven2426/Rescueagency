package com.example.allapplication.epubreader

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Menu
import android.view.View
import android.widget.FrameLayout
import android.widget.PopupWindow
import android.widget.SeekBar
import android.widget.Switch
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.example.allapplication.R
import com.example.allapplication.databinding.ActivityReaderBinding
//import com.folioreader.FolioReader
import com.github.barteksc.pdfviewer.PDFView
import java.io.File


class ReaderActivity : AppCompatActivity() {

    private lateinit var binding: ActivityReaderBinding
    private lateinit var pdfView: PDFView
//    private var folioReader: FolioReader? = null
    private var isDarkTheme = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityReaderBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)

//        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        binding.toolbar.setOnMenuItemClickListener {
            when (it.itemId) {
                R.id.action_settings -> {
                    showSettingsPopup()
                    true
                }

                else -> {
                    false
                }
            }
        }

        val assetFileName = "sample.pdf"
        val filePath = File(cacheDir, assetFileName)
        val fileType = getFileType(filePath.toString())

        when (fileType) {
            "pdf" -> showPdf("sample.pdf",binding.readerContainer)
//            "epub" -> showEpub(filePath)
//            "doc" -> showDoc(filePath)
            else -> showUnsupportedFileMessage()
        }

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.toolbar_menu, menu)
        return true
    }

    private fun showPdf(filePath: String, container: FrameLayout) {
        pdfView = PDFView(this, null)
        container.addView(pdfView)
        pdfView.fromAsset(filePath).load()
    }

//    private fun showEpub(filePath: String) {
//        val folioReader = FolioReader.get()
//        folioReader.openBook(filePath)
//    }

    private fun showSettingsPopup() {
        val popupView: View = layoutInflater.inflate(R.layout.pop_up_settings, null)
        val popupWindow = PopupWindow(popupView, FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, true)

        // Show the popup window
        popupWindow.showAsDropDown(binding.toolbar, binding.toolbar.width - popupWindow.width, 0)

        val brightnessSB:SeekBar = popupView.findViewById(R.id.brightnessSB)
        val fontSizeSB:SeekBar = popupView.findViewById(R.id.fontSizeSB)
        val themeSwitch:Switch = popupView.findViewById(R.id.theme_switch)

        val curBrightness = Settings.System.getInt(
            contentResolver, Settings.System.SCREEN_BRIGHTNESS, 0
        )

        // Set progress of SeekBar to current brightness
        brightnessSB.progress = curBrightness
        pdfView.zoomTo(fontSizeSB.progress.toFloat() / 10)

        // Add SeekBar change listener
        brightnessSB.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                checkWriteSettingsPermission(progress)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}

            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        // Add SeekBar change listener for font size
        fontSizeSB.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                pdfView.zoomTo(progress.toFloat() / 10 + 1) // Adjust zoom level
                pdfView.invalidate()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        themeSwitch.setOnCheckedChangeListener { _, _ ->
            if (themeSwitch.isChecked) {
                // Switch to dark mode
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            } else {
                // Switch to light mode
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            }
        }


    }

    private fun showUnsupportedFileMessage() {
        Toast.makeText(this, "Unsupported file type", Toast.LENGTH_SHORT).show()
    }

    fun getFileType(filePath: String): String {
        return when {
            filePath.endsWith(".pdf", true) -> "pdf"
            filePath.endsWith(".epub", true) -> "epub"
//            filePath.endsWith(".doc", true) || filePath.endsWith(".docx", true) -> "doc"
            else -> "unsupported"
        }
    }

    private fun checkWriteSettingsPermission(progress: Int) {
        if (!Settings.System.canWrite(this)) {
            // If permission not granted, launch the Settings activity to grant permission
            val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS)
            intent.data = Uri.parse("package:" + this.packageName)
            startActivityForResult(intent, REQUEST_WRITE_SETTINGS_PERMISSION)
        } else {
            // Permission has already been granted, proceed with changing brightness
            Settings.System.putInt(
                contentResolver, Settings.System.SCREEN_BRIGHTNESS, progress
            )
        }
    }

    override fun onDestroy() {
        super.onDestroy()
//        folioReader?.close()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_WRITE_SETTINGS_PERMISSION) {
            if (Settings.System.canWrite(this)) {
                Settings.System.putInt(
                    contentResolver, Settings.System.SCREEN_BRIGHTNESS, 0
                )
            } else {
                // Permission not granted, show a message or handle it accordingly
                Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show()
            }
        }
    }

    companion object {
        private const val REQUEST_WRITE_SETTINGS_PERMISSION = 1001
    }
}