package com.example.allapplication.googlemap;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageButton;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;

import com.example.allapplication.MainActivity;
import com.example.allapplication.R;
import com.example.allapplication.com.github.AppLocationService;
import com.example.allapplication.com.github.LocationAddress;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;

import android.location.Location;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PointOfInterest;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.libraries.places.api.Places;
import com.google.maps.android.SphericalUtil;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainMapActivity extends AppCompatActivity implements OnMapReadyCallback{
    LocationManager locationManager;
    private final int FINE_PERMISSION_CODE = 1;
    private Location currentLocation;
    private GoogleMap mMap;
    FusedLocationProviderClient fusedLocationProviderClient;
    AppCompatImageButton imMyLocation;
    SupportMapFragment mapFragment;
    double lat,lng;
    String addressString;
    TextView tvShowAddress;
    Location location;
    Button bTrack;
    Double distance;
    LatLng gndy = new LatLng(13.010236, 80.215652);
    AppLocationService appLocationService;
    LatLng TamWorth ;
    private ArrayList<LatLng> locationArrayList= new ArrayList<>();
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_map);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map1);
        mapFragment.getMapAsync(this);
        appLocationService = new AppLocationService(MainMapActivity.this);

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(MainMapActivity.this);

        imMyLocation=findViewById(R.id.myLocation);
        tvShowAddress=findViewById(R.id.showAddress);
        bTrack=findViewById(R.id.track);
        imMyLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getLastLocation();
            }
        });
        bTrack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                multipleMarker();
            }
        });
        //area address
    }
    private void drawCircle(LatLng point){
        // Instantiating CircleOptions to draw a circle around the marker
        CircleOptions circleOptions = new CircleOptions();
        // Specifying the center of the circle
        circleOptions.center(point);
        // Radius of the circle
        circleOptions.radius(100);
        // Border color of the circle
        circleOptions.strokeColor(Color.BLACK);
        // Fill color of the circle
        circleOptions.fillColor(0x30ff0000);
        // Border width of the circle
        circleOptions.strokeWidth(2);
        // Adding the circle to the GoogleMap
        mMap.addCircle(circleOptions);
    }

    private void multipleMarker()
    {
        TamWorth = new LatLng(12.967267, 80.219465);
        LatLng NewCastle = new LatLng(12.922915, 80.127457);
        LatLng Brisbane = new LatLng(12.904759, 80.089081);
        locationArrayList.add(gndy);
        locationArrayList.add(TamWorth);
        locationArrayList.add(NewCastle);
        locationArrayList.add(Brisbane);
        for (int i = 0; i < locationArrayList.size(); i++) {

            // below line is use to add marker to each location of our array list.
            mMap.addMarker(new MarkerOptions().position(locationArrayList.get(i)).title("Marker"));

            // below line is use to zoom our camera on map.
            mMap.animateCamera(CameraUpdateFactory.zoomTo(18.0f));

            // below line is use to move our camera to the specific location.
            mMap.moveCamera(CameraUpdateFactory.newLatLng(locationArrayList.get(i)));
        }
    }

    private void getLastLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) !=
            PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this,
            Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    FINE_PERMISSION_CODE);
            return;
        }
        Task<Location> task = fusedLocationProviderClient.getLastLocation();
        task.addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                if(location!=null)
                {
                    mMap.clear();
                    LatLng sydney = new LatLng(location.getLatitude(), location.getLongitude());
                    mMap.addMarker(new MarkerOptions().position(sydney).title("my location")
                            .icon(BitmapFromVector(MainMapActivity.this,R.drawable.mylcoation1)));
                    mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(sydney, 17f));
                    setLocation(location.getLatitude(),location.getLongitude());
                    drawCircle(sydney);
                    distance = SphericalUtil.computeDistanceBetween(sydney, locationArrayList.get(0));
                    float f=Float.parseFloat(String.format("%.2f", distance / 1000));
                    float nearLocation=f;
                    for (int i = 0; i < locationArrayList.size(); i++) {
                        // below line is use to add marker to each location of our array list.
                        distance = SphericalUtil.computeDistanceBetween(sydney, locationArrayList.get(i));
                         f=Float.parseFloat(String.format("%.2f", distance / 1000));
                         if(nearLocation>f){
                             mMap.addMarker(new MarkerOptions().position(locationArrayList.get(i)).title("Marker"));
                             nearLocation=f;
                             mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(locationArrayList.get(i), 17f));
                         }
                    }
                    Toast.makeText(MainMapActivity.this, "Distance between Sydney and Brisbane is \n " +
                            nearLocation+ "km", Toast.LENGTH_SHORT).show();
//                    setLocation(location.getLatitude(),location.getLongitude());
//                    getAddress(location.getLatitude(),location.getLongitude());
                }
                else{
                    Toast.makeText(MainMapActivity.this, "require location", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permission,@NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permission, grantResults);
        if(requestCode==FINE_PERMISSION_CODE)
        {
            if(grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED)
            {
                getLastLocation();
            }else{
                Toast.makeText(this, "need Location permission", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void setLocation(double lat,double lng){
        Geocoder mGeocoder = new Geocoder(getApplicationContext(), Locale.getDefault());
        String addressString = "";
        // Reverse-Geocoding starts
        try {
            List<Address> addressList = mGeocoder.getFromLocation(lat, lng, 1);

            // use your lat, long value here
            if (addressList != null && !addressList.isEmpty()) {
                Address address = addressList.get(0);

                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < address.getMaxAddressLineIndex(); i++) {
                    sb.append(address.getAddressLine(i)).append("\n");
                }
                // Various Parameters of an Address are appended
                // to generate a complete Address
                if (address.getPremises() != null)
                    sb.append(address.getPremises()).append(", ");

                sb.append(address.getSubAdminArea()).append("\n");
                sb.append(address.getLocality()).append(", ");
                sb.append(address.getAdminArea()).append(", ");
                sb.append(address.getCountryName()).append(", ");
                sb.append(address.getPostalCode());

                // StringBuilder sb is converted into a string
                // and this value is assigned to the
                // initially declared addressString string.
                addressString = sb.toString();
            }
        } catch (IOException e) {
            Toast.makeText(getApplicationContext(), "Unable connect to Geocoder", Toast.LENGTH_LONG).show();
        }

        // Finally, the address string is posted in the textView with LatLng.
        tvShowAddress.setText("Lat: " + lat + "\nLng: " + lng + "\nAddress: " + addressString);
    }
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap=googleMap;
    }
    //custome marker for google map
    private BitmapDescriptor  BitmapFromVector(Context context, int vectorResId)
    {
        // below line is use to generate a drawable.
        Drawable vectorDrawable = ContextCompat.getDrawable(context, vectorResId);
        // below line is use to set bounds to our vector
        // drawable.
        vectorDrawable.setBounds(0, 0, vectorDrawable.getIntrinsicWidth(),vectorDrawable.getIntrinsicHeight());
        // below line is use to create a bitmap for our
        // drawable which we have added.
        Bitmap bitmap = Bitmap.createBitmap(vectorDrawable.getIntrinsicWidth(),
                vectorDrawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        // below line is use to add bitmap in our canvas.
        Canvas canvas = new Canvas(bitmap);
        // below line is use to draw our
        // vector drawable in canvas.
        vectorDrawable.draw(canvas);
        // after generating our bitmap we are returning our
        // bitmap.
        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }


    public void getLocationSecondWay()
    {
        location = appLocationService.getLocation(LocationManager.GPS_PROVIDER);
        double latitude = 13.1000727;
        double longitude = 80.2126274;
        LocationAddress locationAddress = new LocationAddress();
        locationAddress.getAddressFromLocation(latitude, longitude,
                getApplicationContext(), new GeoCodeHandler());
        showSettingsAlert();
    }

    public void showSettingsAlert() {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(MainMapActivity.this);
        alertDialog.setTitle("SETTINGS");
        alertDialog.setMessage("Enable Location Provider! Go to settings menu?");
        alertDialog.setPositiveButton("Settings", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                MainMapActivity.this.startActivity(intent);
            }
        });
        alertDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        alertDialog.show();
    }
    class GeoCodeHandler extends Handler {
        @Override
        public void handleMessage(Message message) {
            String locationAddress;
            switch (message.what) {
                case 1:
                    Bundle bundle = message.getData();
                    locationAddress = bundle.getString("address");
                    break;
                default:
                    locationAddress = null;
            }
            tvShowAddress.setText(locationAddress);
        }
    }
}

