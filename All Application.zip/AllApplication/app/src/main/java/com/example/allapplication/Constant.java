package com.example.allapplication;

public enum Constant {

    SF_NAME

}
