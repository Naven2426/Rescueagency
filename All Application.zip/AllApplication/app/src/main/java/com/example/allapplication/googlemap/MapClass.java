package com.example.allapplication.googlemap;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.allapplication.R;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.libraries.places.api.Places;


import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class MapClass extends AppCompatActivity implements OnMapReadyCallback, GoogleApiClient.ConnectionCallbacks,GoogleApiClient.OnConnectionFailedListener,
        LocationListener, GoogleMap.OnMarkerClickListener, GoogleMap.OnMarkerDragListener {

    private GoogleMap mMap;
    double lat;
    double lng;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Fetching API_KEY which we wrapped
        try {
            ApplicationInfo ai = getApplicationContext().getPackageManager().getApplicationInfo(getApplicationContext()
                    .getPackageName(), PackageManager.GET_META_DATA);
            Bundle bundle = ai.metaData;
            String apiKey = bundle.getString("com.google.android.geo.API_KEY");

            // Initializing the Places API
            // with the help of our API_KEY

            if (!Places.isInitialized()) {
                Places.initialize(getApplicationContext(), apiKey);
            }

            // Initializing map
            SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
            mapFragment.getMapAsync(this);

        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {

        mMap = googleMap;

        // These are GeeksforGeeks Noida Office Coordinates.
        LatLng india = new LatLng(28.5021359, 77.4054901);
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(india, 17f));

        mMap.setOnCameraIdleListener(() -> {
         lat = mMap.getCameraPosition().target.latitude;
         lng = mMap.getCameraPosition().target.longitude;
            TextView addressTV =null;//= findViewById(R.id.tv);

            // Initializing Geocoder
            Geocoder mGeocoder = new Geocoder(getApplicationContext(), Locale.getDefault());
            String addressString = "";

            // Reverse-Geocoding starts
            try {
                List<Address> addressList = mGeocoder.getFromLocation(lat, lng, 1);

                // use your lat, long value here
                if (addressList != null && !addressList.isEmpty()) {
                    Address address = addressList.get(0);
                    StringBuilder sb = new StringBuilder();
                    for (int i = 0; i < address.getMaxAddressLineIndex(); i++) {
                        sb.append(address.getAddressLine(i)).append("\n");
                    }

                    // Various Parameters of an Address are appended
                    // to generate a complete Address
                    if (address.getPremises() != null)
                        sb.append(address.getPremises()).append(", ");

                    sb.append(address.getSubAdminArea()).append("\n");
                    sb.append(address.getLocality()).append(", ");
                    sb.append(address.getAdminArea()).append(", ");
                    sb.append(address.getCountryName()).append(", ");
                    sb.append(address.getPostalCode());

                    // StringBuilder sb is converted into a string
                    // and this value is assigned to the
                    // initially declared addressString string.
                    addressString = sb.toString();
                }
            } catch (IOException e) {
                Toast.makeText(getApplicationContext(), "Unable connect to Geocoder", Toast.LENGTH_LONG).show();
            }

            // Finally, the address string is posted in the textView with LatLng.
            addressTV.setText("Lat: " + lat + "\nLng: " + lng + "\nAddress: " + addressString);
        });
    }

    @Override
    public boolean onMarkerClick(@NonNull Marker marker) {
        marker.setDraggable(true);
        return false;
    }

    @Override
    public void onMarkerDrag(@NonNull Marker marker) {

    }

    @Override
    public void onMarkerDragEnd(@NonNull Marker marker) {

    }

    @Override
    public void onMarkerDragStart(@NonNull Marker marker) {

    }

    @Override
    public void onLocationChanged(@NonNull Location location) {

    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {

    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }
}
