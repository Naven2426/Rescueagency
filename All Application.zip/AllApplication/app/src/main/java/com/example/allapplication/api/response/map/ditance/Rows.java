package com.example.allapplication.api.response.map.ditance;

import java.util.List;

public class Rows {
    private List<Elements> elements;

    public void setElements(List<Elements> elements) {
        this.elements = elements;
    }
    public List<Elements> getElements() {
        return elements;
    }
}
