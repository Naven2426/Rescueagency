package com.example.allapplication;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
//import retrofit2.converter.jackson.JacksonConverterFactory;
public class RestClient {
    private static RestClient self;
//    private final String API_BASE_URL = "https://maps.googleapis.com/maps/api/";
    public static final String API_BASE_URL = "https://722e-2409-4072-80e-c767-c03c-e65a-b5ea-e6e5.ngrok-free.app";
    private Retrofit retrofit;

    private  RestClient() {
        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
        interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        OkHttpClient httpClient = new OkHttpClient.Builder().addInterceptor(interceptor).build();

        Retrofit.Builder builder =
                new Retrofit.Builder()
                        .baseUrl(API_BASE_URL)
                        .addConverterFactory(GsonConverterFactory.create());
        retrofit = builder.client(httpClient).build();
    }

    public static RestClient getInstance() {
        if (self == null) {
            synchronized(RestClient.class) {
                if (self == null) {
                    self = new RestClient();
                }
            }
        }
        return self;
    }
    public static API getApi(){
        return getInstance().getRetrofit().create(API.class);
    }

    public  Retrofit getRetrofit() {
        return retrofit;
    }
}
