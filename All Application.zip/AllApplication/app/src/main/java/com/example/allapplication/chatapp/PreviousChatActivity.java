package com.example.allapplication.chatapp;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.allapplication.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URISyntaxException;
import java.util.ArrayList;

import io.socket.client.IO;
import io.socket.client.Socket;
import io.socket.emitter.Emitter;

public class PreviousChatActivity extends AppCompatActivity {

    private Socket mSocket;
    private ArrayAdapter<String> mAdapter;
    private ArrayList<String> mMessages;
    private int userId = 1; // Replace with actual user ID
    private int otherUserId = 2; // Replace with the ID of the other user in the chat

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_previous_chat);

        ListView messageListView = findViewById(R.id.message_list);
        EditText messageInput = findViewById(R.id.message_input);
        Button sendButton = findViewById(R.id.send_button);

        mMessages = new ArrayList<>();
        mAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, mMessages);
        messageListView.setAdapter(mAdapter);

        try {
            mSocket = IO.socket("https://1254-2409-4072-484-7f38-8d24-dad2-7275-c5ed.ngrok-free.app");
            mSocket.connect();
            mSocket.on(Socket.EVENT_CONNECT, onConnect);
            mSocket.on("messageHistory", onMessageHistory);
            mSocket.on("newMessage", onNewMessage);
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }

        mSocket.emit("join", userId);
        mSocket.emit("loadMessages", otherUserId);

        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String message = messageInput.getText().toString();
                if (!message.isEmpty()) {
                    try {
                        JSONObject msg = new JSONObject();
                        msg.put("senderId", userId);
                        msg.put("receiverId", otherUserId);
                        msg.put("content", message);
                        mSocket.emit("newMessage", msg);
                        messageInput.setText("");
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
    }

    private Emitter.Listener onConnect = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            // Handle connection event if needed
        }
    };

    private Emitter.Listener onMessageHistory = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    JSONArray messages = (JSONArray) args[0];
                    for (int i = 0; i < messages.length(); i++) {
                        try {
                            JSONObject message = messages.getJSONObject(i);
                            mMessages.add(message.getString("content"));
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                    mAdapter.notifyDataSetChanged();
                }
            });
        }
    };


    private Emitter.Listener onNewMessage = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    JSONObject message = (JSONObject) args[0];
                    try {
                        int senderId = message.getInt("sender_id");
                        int receiverId = message.getInt("receiver_id");

                        if ((senderId == userId && receiverId == otherUserId) || (senderId == otherUserId && receiverId == userId)) {
                            mMessages.add(message.getString("content"));
                            mAdapter.notifyDataSetChanged();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            });
        }
    };

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mSocket.disconnect();
        mSocket.off(Socket.EVENT_CONNECT, onConnect);
        mSocket.off("messageHistory", onMessageHistory);
        mSocket.off("newMessage", onNewMessage);
    }

}