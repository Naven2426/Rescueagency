package com.example.allapplication.multiple.images.upload;

import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewSwitcher;

import android.database.Cursor;

import com.example.allapplication.API;
import com.example.allapplication.R;
import com.example.allapplication.api.response.CommonResponse;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.RequestBody;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MultipleImagesUploadActivity extends AppCompatActivity {

    Button select, previous, next;
    ImageSwitcher imageView;
    int PICK_IMAGE_MULTIPLE = 123;
    String imageEncoded;
    TextView total;
    ArrayList<Uri> mArrayUri;
    List<MultipartBody.Part> mPart;
    ArrayList<Cursor> curs;
    int position = 0;
    List<String> imagesEncodedList;
    Bitmap bitmap;

    private void apiCall(RequestBody name, List<MultipartBody.Part> mPart) {
        HttpLoggingInterceptor httpLoggingInterceptor = new HttpLoggingInterceptor();
        httpLoggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(60, TimeUnit.SECONDS)
                .writeTimeout(60, TimeUnit.SECONDS)
                .readTimeout(60, TimeUnit.SECONDS)
                .addInterceptor(httpLoggingInterceptor)
//                .retryOnConnectionFailure(true)
                .build();

        Retrofit retrofit = new Retrofit.Builder()
                .addConverterFactory(GsonConverterFactory.create())
                .baseUrl("https://2efe-2409-4072-683-8f65-85fb-1ec4-dc7c-b361.ngrok-free.app/Maid/mhms/api/")  //Change server URL
                .client(client)
                .build();

        API api = retrofit.create(API.class);
        Call<CommonResponse> call = api.postMultipleImages("name", mPart);
        call.enqueue(new Callback<CommonResponse>() {
            @Override
            public void onResponse(Call<CommonResponse> call, Response<CommonResponse> response) {
                if (response.isSuccessful()) {
                    if (response.body().getStatus() == 200) {
                        Toast.makeText(MultipleImagesUploadActivity.this, "200 " + response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(MultipleImagesUploadActivity.this, "400 " + response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(MultipleImagesUploadActivity.this, "server busy ", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<CommonResponse> call, Throwable t) {
                Log.e(TAG, "onFailure " + t.getMessage());
                Toast.makeText(MultipleImagesUploadActivity.this, "onFailure " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // When an Image is picked
        if (requestCode == PICK_IMAGE_MULTIPLE && resultCode == RESULT_OK && null != data) {
            // Get the Image from data
            if (data.getClipData() != null) {

                ClipData mClipData = data.getClipData();
                int cout = data.getClipData().getItemCount();
//                Toast.makeText(MultipleImagesUploadActivity.this,"hh "+mClipData.getItemAt(0).getUri().getPath(),Toast.LENGTH_LONG).show();
                for (int i = 0; i < cout; i++) {

                    // adding imageuri in array
                    Uri imageurl = data.getClipData().getItemAt(i).getUri();
//                    String path= null;

//                    path = FileUtils.getPath(MultipleImagesUploadActivity.this,imageurl);


//                    Toast.makeText(MultipleImagesUploadActivity.this,"hh "+imageurl.getPath(),Toast.LENGTH_LONG).show();
//                    RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
//
                    mArrayUri.add(imageurl);
                }
//                File file=new File("storage/emulated/0/Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Images/IMG-20240401-WA0012.jpg");
//                Log.e(TAG,"path from on activity result "+file.getPath());
//                RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
//                mPart.add(MultipartBody.Part.createFormData("img[]",file.getName(), reqFile));
//                RequestBody name = RequestBody.create(MediaType.parse("text/plain"), "java");
//                apiCall(name,mPart);
                // setting 1st selected image into image switcher
                imageView.setImageURI(mArrayUri.get(0));
                position = 0;
            } else {
                Uri imageurl = data.getData();
                mArrayUri.add(imageurl);
                imageView.setImageURI(mArrayUri.get(0));
                position = 0;
            }
        } else {
            // show this if no image is selected
            Toast.makeText(this, "You haven't picked Image", Toast.LENGTH_LONG).show();
        }
    }

    private Uri getImageUri(Context context, String imageView) throws FileNotFoundException {
        String path = MediaStore.Images.Media.insertImage(context.getContentResolver(), imageView, "myImage", "");
        return Uri.parse(path);
    }

    public String getRealPathFromUri(Uri uri) {
        String[] projection = {MediaStore.Images.Media.DATA};
        Cursor cursor = getContentResolver().query(uri, projection, null, null, null);
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        String path = cursor.getString(column_index);
        cursor.close();
        return path;
    }

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_multiple_images_upload);
        select = findViewById(R.id.select);
        total = findViewById(R.id.text);
        imageView = findViewById(R.id.image);
        previous = findViewById(R.id.previous);
        mArrayUri = new ArrayList<Uri>();
        findViewById(R.id.submit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                mPart=new ArrayList<>();
                RequestBody name = RequestBody.create(MediaType.parse("text/plain"), "java");

//                File file1 = new File("/storage/emulated/0/Download/Snapinsta.app_427871823_378682384800393_4205111512544834922_n_1080-fotor-202403307921.jpg");
//                //name=Screenshot_20240402_062700.jpg
//                File file = new File("/storage/emulated/0/DCIM/Screenshots/Screenshot_20240402_062700.jpg");
//                //path=/storage/emulated/0/DCIM/Screenshots/Screenshot_20240402_062700.jpg
//                Log.e(TAG,"file name "+file1.getName());
//                RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file1);
//                RequestBody reqFile1 = RequestBody.create(MediaType.parse("image/*"), file);
//                mPart.add(MultipartBody.Part.createFormData("img", file1.getName(), reqFile));
//                mPart.add(MultipartBody.Part.createFormData("img", file.getName(), reqFile1));
//                apiCall(name,mPart);
            }
        });
        // showing all images in imageswitcher
        imageView.setFactory(new ViewSwitcher.ViewFactory() {
            @Override
            public View makeView() {
                ImageView imageView1 = new ImageView(getApplicationContext());
                return imageView1;
            }
        });
        next = findViewById(R.id.next);

        // click here to select next image
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (position < mArrayUri.size() - 1) {
                    // increase the position by 1
                    position++;

                    imageView.setImageURI(mArrayUri.get(position));
                } else {
                    Toast.makeText(MultipleImagesUploadActivity.this, "Last Image Already Shown", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // click here to view previous image
        previous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (position > 0) {
                    // decrease the position by 1
                    position--;
                    imageView.setImageURI(mArrayUri.get(position));
                }
                if (mArrayUri != null) {
                    for (int i = 0; i < mArrayUri.size(); i++) {
                        Log.e(TAG, "path uri " + mArrayUri.get(i));
                    }
                }
            }
        });

        imageView = findViewById(R.id.image);

        // click here to select image
        select.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // initialising intent
                Intent intent = new Intent();
//                startActivityForResult(intent, 1);

                // setting type to select to be image
                intent.setType("image/*");

                // allowing multiple image to be selected
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent, "Select Picture"), 123);
            }
        });

    }
}