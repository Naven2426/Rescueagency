package com.example.allapplication.commonactivity.simplegalaryapp;

import android.annotation.SuppressLint;
import android.net.Uri;
import android.os.Bundle;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.PickVisualMediaRequest;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.example.allapplication.R;

import java.util.ArrayList;
import java.util.List;

public class GalaryViewFragment extends Fragment {

    String imgPath;
    private ImageView imageView;
    private ScaleGestureDetector scaleGestureDetector;
    private float mScaleFactor = 1.0f;
    List<Uri> images=new ArrayList<>();
    ActivityResultLauncher<PickVisualMediaRequest> pickMedia =
            registerForActivityResult(new ActivityResultContracts.PickMultipleVisualMedia(), uri -> {
                // Callback is invoked after the user selects a media item or closes the
                // photo picker.
                if (uri != null) {
                    images.addAll(uri);
                    recyclerView();
                } else {
                    Log.d("PhotoPicker", "No media selected");
                }
            });
    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,  Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_galary_view, container, false);
        viewPager2=view.findViewById(R.id.viewPager2);
        pickMedia.launch(new PickVisualMediaRequest.Builder()
                .setMediaType(ActivityResultContracts.PickVisualMedia.ImageOnly.INSTANCE)
                .build());

        return view;
    }
    ViewPager2 viewPager2;
    private void recyclerView(){
        ViewPagerAdapter viewPagerAdapter=new ViewPagerAdapter(images);
        viewPager2.setAdapter(viewPagerAdapter);
    }
    private class ViewPagerAdapter extends RecyclerView.Adapter<ViewPagerAdapter.MyViewHolder>{
        List<Uri> images;
        public ViewPagerAdapter(List<Uri> images) {
            this.images = images;
        }
        @NonNull
        @Override
        public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new MyViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_image,parent,false));
        }

        @Override
        public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
            holder.textView.setText("hi");
            holder.imageView.setImageURI(images.get(position));
        }

        @Override
        public int getItemCount() {
            return images.size();
        }

        class MyViewHolder extends  RecyclerView.ViewHolder{
            AppCompatImageView imageView;
            AppCompatTextView textView;
            public MyViewHolder(@NonNull View itemView) {
                super(itemView);
                imageView=itemView.findViewById(R.id.imagePreview);
//                textView=itemView.findViewById(R.id.imagePreview);
            }
        }
    }
}