package com.example.allapplication.api.response.map.nearbyapi;

public class Geometry {
    private Location location;
    private Viewport viewport;

    public void setLocation(Location location) {
        this.location = location;
    }
    public Location getLocation() {
        return location;
    }
    public void setViewport(Viewport viewport) {
        this.viewport = viewport;
    }
    public Viewport getViewport() {
        return viewport;
    }
}

