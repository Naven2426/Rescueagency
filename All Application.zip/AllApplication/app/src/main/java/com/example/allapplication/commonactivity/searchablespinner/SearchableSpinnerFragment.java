package com.example.allapplication.commonactivity.searchablespinner;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.PickVisualMediaRequest;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.allapplication.R;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


public class SearchableSpinnerFragment extends Fragment {

    TextView textview;
    ArrayList<String> arrayList;
    private List<Uri> uri;
    ViewPager2 viewPager2;
    private final ActivityResultLauncher<PickVisualMediaRequest> pickMedia =
            registerForActivityResult(new ActivityResultContracts.PickMultipleVisualMedia(50), uri -> {
                // Callback is invoked after the user selects a media item or closes the
                // photo picker.
                this.uri = uri;
                if (this.uri != null) {
                    recyclerView(uri);
                } else {
                    Toast.makeText(getContext(), "No media selected", Toast.LENGTH_SHORT).show();
                }
            });
    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_searchable_spinner, container, false);
        viewPager2=view.findViewById(R.id.showImages_view_pager2);
        view.findViewById(R.id.selectButton).setOnClickListener(v -> pickMedia.launch(new PickVisualMediaRequest.Builder()
                .setMediaType(ActivityResultContracts.PickVisualMedia.ImageOnly.INSTANCE)
                .build())
        );
        searchableSpinner(view);
        return view;
    }
    private void recyclerView(List<Uri> uri){
        viewPager2.setAdapter(new ProductImagesAdapter(getActivity(), uri));
        viewPager2.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            // This method is triggered when there is any scrolling activity for the current page
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                super.onPageScrolled(position, positionOffset, positionOffsetPixels);
            }

            // triggered when you select a new page
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
            }

            // triggered when there is
            // scroll state will be changed
            @Override
            public void onPageScrollStateChanged(int state) {
                super.onPageScrollStateChanged(state);
            }
        });
    }
    private void searchableSpinner(View view) {
        textview=view.findViewById(R.id.testView);

        // initialize array list
        arrayList=new ArrayList<>();
        arrayList.add("DSA Self Paced");
        arrayList.add("Complete Interview Prep");
        arrayList.add("Amazon SDE Test Series");
        arrayList.add("Compiler Design");
        arrayList.add("Git & Github");
        arrayList.add("Python foundation");
        arrayList.add("Operating systems");
        arrayList.add("Theory of Computation");
        textview.setOnClickListener(v -> dialogFunction(new Dialog(requireContext())));
    }
    private void dialogFunction(Dialog dialog) {

        // set custom dialog
        dialog.setContentView(R.layout.dialog_layout_for_searchable_spinner);

        // set custom height and width
        Objects.requireNonNull(dialog.getWindow()).setLayout(650,800);

        // set transparent background
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        // show dialog
        dialog.show();
        EditText editText=dialog.findViewById(R.id.edit_text);
        ListView listView=dialog.findViewById(R.id.list_view);
        ArrayAdapter<String> adapter=new ArrayAdapter<>(requireContext(), android.R.layout.simple_list_item_1,arrayList);
        listView.setAdapter(adapter);
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                adapter.getFilter().filter(s);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        listView.setOnItemClickListener((parent, view, position, id) -> {
            // when item selected from list
            // set selected item on textView
            textview.setText(adapter.getItem(position));

            // Dismiss dialog
            dialog.dismiss();
        });
    }
    private class ProductImagesAdapter  extends RecyclerView.Adapter<ProductImagesAdapter.MyViewHolder>{

        FragmentActivity activity;
        List<Uri> list;
        public ProductImagesAdapter(FragmentActivity activity, List<Uri> list) {
            this.activity = activity;
            this.list = list;
        }

        @NonNull
        @Override
        public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new MyViewHolder(LayoutInflater.from(getContext()).inflate(R.layout.recycler_layout_add_product_fragment_for_product_images,parent,false));
        }

        @Override
        public void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") int position) {
            holder.productImagesAppCompatImageView.setImageURI(list.get(position));
            holder.productImagesAppCompatImageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(activity, "adapter position "+position, Toast.LENGTH_SHORT).show();

                }
            });
        }

        @Override
        public int getItemCount() {
            return list.size();
        }

        class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
            AppCompatImageView productImagesAppCompatImageView;
            public MyViewHolder(@NonNull View itemView) {
                super(itemView);
                productImagesAppCompatImageView = itemView.findViewById(R.id.id_recycler_layout_add_product_product_image);
                itemView.setOnClickListener(this);
            }
            @Override
            public void onClick(View view) {
                Toast.makeText(view.getContext(), "holder position "+getAdapterPosition(), Toast.LENGTH_SHORT).show();
            }
        }
    }

}