package com.example.allapplication.epubreader;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatButton;
import androidx.fragment.app.Fragment;

import android.provider.DocumentsContract;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import io.hamed.htepubreadr.component.EpubReaderComponent;
import io.hamed.htepubreadr.entity.BookEntity;
import io.hamed.htepubreadr.entity.SubBookEntity;
import io.hamed.htepubreadr.ui.view.EpubView;
import io.hamed.htepubreadr.ui.view.OnHrefClickListener;
import io.hamed.htepubreadr.util.EpubUtil;
import nl.joery.animatedbottombar.AnimatedBottomBar;

import com.example.allapplication.R;
import com.example.allapplication.multiple.images.upload.FileUtils;
import com.github.mertakdut.BookSection;
import com.github.mertakdut.Reader;
import com.github.mertakdut.exception.OutOfPagesException;
import com.github.mertakdut.exception.ReadingException;

import java.io.IOException;
import java.util.List;

public class MainEpubFragment extends Fragment {
    private static final int CREATE_FILE = 1;

    private void selectPDF()
    {
        // Initialize intent
        Intent intent
                = new Intent(Intent.ACTION_GET_CONTENT);
        // set type
        intent.setType("application/*");
        // Launch intent
        resultLauncher.launch(intent);
    }
    private void setResultLauncher(){
        resultLauncher = registerForActivityResult(
                new ActivityResultContracts
                        .StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result)
                    {
                        // Initialize result data
                        Intent data = result.getData();
                        // check condition
                        if (data != null) {
                            // When data is not equal to empty
                            // Get PDf uri
                            Uri sUri = data.getData();
                            // set Uri on text view


                            // Get PDF path
                            String sPath = sUri.getPath();
                            String filePath=FileUtils.getPath(requireContext(),sUri);
                            Log.e("epub file path",filePath);
                            // Set path on text view
                            try {
                                epubReader(filePath);
                            } catch (Exception e) {
                                Log.e("epub error",e.getMessage());
                                e.printStackTrace();
                            }
                        }
                    }
                });
    }
    ActivityResultLauncher<Intent> resultLauncher;
    View view;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
         view= inflater.inflate(R.layout.fragment_main_epub, container, false);
        setResultLauncher();
        String path="";
        @SuppressLint({"MissingInflatedId", "LocalSuppress"})
        AppCompatButton btn_epub=view.findViewById(R.id.select_epub);
        btn_epub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectPDF();
            }
        });
        Reader reader = new Reader();
        reader.setMaxContentPerSection(1000); // Max string length for the current page.
        reader.setIsIncludingTextContent(true); // Optional, to return the tags-excluded version.
        try {
            reader.setFullContent("epubFilePath"); // Must call before readSection.
        } catch (ReadingException e) {
            throw new RuntimeException(e);
        }

        BookSection bookSection = null;
        try {
            bookSection = reader.readSection(1);
        } catch (ReadingException e) {
            throw new RuntimeException(e);
        } catch (OutOfPagesException e) {
            throw new RuntimeException(e);
        }
        String sectionContent = bookSection.getSectionContent(); // Returns content as html.
        String sectionTextContent = bookSection.getSectionTextContent();
        return view;
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults)
    {
        super.onRequestPermissionsResult( requestCode, permissions, grantResults);
        // check condition
        if (requestCode == 1 && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            // When permission is granted
            // Call method
            selectPDF();
        }
        else {
            // When permission is denied
            // Display toast
            Toast.makeText(requireContext(),"Permission Denied",Toast.LENGTH_SHORT).show();
        }
    }
    private void epubReader(String path) throws Exception {
        EpubReaderComponent epubReaderComponent = new EpubReaderComponent(path);
        BookEntity bookEntity = epubReaderComponent.make(requireContext());
        List<String> allPage = bookEntity.getPagePathList();
        String bookName = bookEntity.getName();
        String authorName = bookEntity.getAuthor();
        String coverImage = bookEntity.getCoverImage();
//        List<SubBookEntity> allPage = bookEntity.getSubBookHref();
        // set file path
        EpubView epubView=view.findViewById(R.id.epub_view);
         epubView.setBaseUrl(epubReaderComponent.getAbsolutePath());
        String content = EpubUtil.getHtmlContent(allPage.get(1));
        epubView.setUp(content);
        epubView.setFontSize(15);
        epubView.setOnHrefClickListener(new OnHrefClickListener() {
            @Override
            public void onClick(String href) {

            }
        });
    }
}