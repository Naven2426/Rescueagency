package com.example.allapplication.chatapp.mychat;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Base64;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.allapplication.R;
import com.example.allapplication.chatapp.ChatActivity;
import com.example.allapplication.chatapp.MessageAdapter;
import com.example.allapplication.databinding.ActivityChatBinding;
import com.example.allapplication.databinding.ActivityWebSocketToSocketIoBinding;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

import io.socket.client.IO;
import io.socket.client.Socket;
import io.socket.emitter.Emitter;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;

public class WebSocketToSocketIoActivity extends AppCompatActivity implements TextWatcher {

    private WebSocket webSocket;
    private String name;
    public static final String SERVER_PATH = "https://c5cd-2409-4072-484-7f38-e97b-2c1-81b1-a841.ngrok-free.app";
    private View sendBtn,pickImgBtn;
    private RecyclerView recyclerView;
    private int IMAGE_REQUEST_ID = 1;
    private ActivityWebSocketToSocketIoBinding binding;
    private EditText messageEdit;
    private MessageAdapter messageAdapter;

    //socket io
    private Socket mSocket;
    {
        try {
            mSocket = IO.socket("https://96b0-2409-4072-80e-c767-4fd-45b5-6e1a-7ce1.ngrok-free.app"); // Use the IP of your server if not using the emulator
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityWebSocketToSocketIoBinding.inflate(getLayoutInflater());
        setContentView(R.layout.activity_web_socket_to_socket_io);
        name = getIntent().getStringExtra("name");
//        initiateSocketConnection();
        mSocket.emit("joinRoom", createUserRoomJson(name, "1234"));
        mSocket.connect();
        initializeViews();
        mSocket.on("message", new Emitter.Listener() {
            @Override
            public void call(final Object... args) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        JSONObject data = (JSONObject) args[0];
                        try {
                            String user = data.getString("user");
                            String message = data.getString("message");
                            data.put("isSent", false);
                            messageAdapter.addItem(data);

                            recyclerView.smoothScrollToPosition(messageAdapter.getItemCount() - 1);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                });
            }
        });
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
        String string = s.toString().trim();

        if (string.isEmpty()) {
            resetMessageEdit();
        } else {

            sendBtn.setVisibility(View.VISIBLE);
            pickImgBtn.setVisibility(View.GONE);
        }
    }

    @Override
    public void afterTextChanged(Editable s) {

    }
    private void resetMessageEdit() {

        messageEdit.removeTextChangedListener(this);

        messageEdit.setText("");
        sendBtn.setVisibility(View.INVISIBLE);
        pickImgBtn.setVisibility(View.VISIBLE);

        messageEdit.addTextChangedListener(this);

    }


    private void initializeViews(){
        messageEdit=findViewById(R.id.messageEdit);
        sendBtn=findViewById(R.id.sendBtn);
        pickImgBtn=findViewById(R.id.pickImgBtn);
        recyclerView=findViewById(R.id.recyclerView);
        messageAdapter = new MessageAdapter(getLayoutInflater());
        recyclerView.setAdapter(messageAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        binding.messageEdit.addTextChangedListener(this);
        sendBtn.setOnClickListener(v -> {

            JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put("message", messageEdit.getText().toString());
                jsonObject.put("room", "1234");
                jsonObject.put("username", name);
//                webSocket.send(jsonObject.toString());
                mSocket.emit("sendMessage",jsonObject);
                jsonObject.put("isSent", true);
                messageAdapter.addItem(jsonObject);

                recyclerView.smoothScrollToPosition(messageAdapter.getItemCount() - 1);

                resetMessageEdit();

            } catch (JSONException e) {
                e.printStackTrace();
            }

        });

    }
    private JSONObject createUserRoomJson(String username, String room) {
        JSONObject json = new JSONObject();
        try {
            json.put("username", username);
            json.put("room", room);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return json;
    }

}