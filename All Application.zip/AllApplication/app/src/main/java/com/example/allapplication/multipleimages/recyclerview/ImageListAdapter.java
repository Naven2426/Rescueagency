package com.example.allapplication.multipleimages.recyclerview;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.example.allapplication.R;
import com.example.allapplication.multiple.images.upload.Fi;

import java.io.File;
import java.util.List;

public class ImageListAdapter extends BaseAdapter {
    Context context;
    List<Uri> list;
    public ImageListAdapter(List<Uri> list,Context context)
    {
        this.context=context;
        this.list=list;
    }
    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        LayoutInflater inflater=LayoutInflater.from(context);
        view=inflater.inflate(R.layout.item_image,null);
        ImageView imageView=view.findViewById(R.id.image);
        File file=new File(list.get(position).getPath());
        Glide.with(context).load(file).apply(new RequestOptions().placeholder(R.drawable.edit_profile) // Placeholder image
                        .error(R.drawable.logo)) // Error image in case of loading failure
                .into(imageView);
        return view;
    }
}
