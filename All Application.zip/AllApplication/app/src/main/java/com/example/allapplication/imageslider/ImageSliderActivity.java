package com.example.allapplication.imageslider;

import android.annotation.SuppressLint;
import android.os.Bundle;

import com.bumptech.glide.Glide;
import com.codebyashish.autoimageslider.AutoImageSlider;
import com.codebyashish.autoimageslider.Enums.ImageActionTypes;
import com.codebyashish.autoimageslider.Enums.ImageAnimationTypes;
import com.codebyashish.autoimageslider.Enums.ImageScaleType;
import com.codebyashish.autoimageslider.Interfaces.ItemsListener;
import com.codebyashish.autoimageslider.Models.ImageSlidesModel;
import com.denzcoskun.imageslider.ImageSlider;
import com.denzcoskun.imageslider.constants.ActionTypes;
import com.denzcoskun.imageslider.constants.ScaleTypes;
import com.denzcoskun.imageslider.interfaces.ItemClickListener;
import com.denzcoskun.imageslider.interfaces.TouchListener;
import com.denzcoskun.imageslider.models.SlideModel;
import com.google.android.material.snackbar.Snackbar;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Handler;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.core.view.WindowCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;
import androidx.viewpager2.widget.CompositePageTransformer;
import androidx.viewpager2.widget.MarginPageTransformer;
import androidx.viewpager2.widget.ViewPager2;


import com.example.allapplication.R;

import java.util.ArrayList;
import java.util.List;

public class ImageSliderActivity extends AppCompatActivity {

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_slider);
        imageSlider();
        viewPager2();
        imageSlider2();
    }
    Handler handler;
    Runnable runnable;
    private void viewPager2()
    {
        ViewPager2 viewPager2=findViewById(R.id.viewPager);
        List<SlideItem> slideItems=new ArrayList<>();
        slideItems.add(new SlideItem(R.drawable.imge1,"hi"));
        slideItems.add(new SlideItem(R.drawable.imge2,"welcome"));
        slideItems.add(new SlideItem(R.drawable.imge3,"good"));
        viewPager2.setAdapter(new SlideAdapter(viewPager2,slideItems));
        viewPager2.setClipToPadding(false);
        viewPager2.setClipChildren(false);
        viewPager2.setOffscreenPageLimit(5);
        viewPager2.getChildAt(0).setOverScrollMode(RecyclerView.OVER_SCROLL_NEVER);
        CompositePageTransformer cpt=new CompositePageTransformer();
        cpt.addTransformer(new MarginPageTransformer(30));
        cpt.addTransformer(new ViewPager2.PageTransformer() {
            @Override
            public void transformPage(@NonNull View page, float position) {
            float f=1-Math.abs(position);
            page.setScaleY(0.85f+f*0.15f);
            }
        });
        viewPager2.setPageTransformer(cpt);
         handler=new Handler();
         runnable=new Runnable() {
            @Override
            public void run() {
                viewPager2.setCurrentItem(viewPager2.getCurrentItem()+1);
            }
        };
        viewPager2.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                handler.removeCallbacks(runnable);
                handler.postDelayed(runnable,2000);
            }
        });

    }
    protected void onPause(){
        super.onPause();
        handler.removeCallbacks(runnable);

    }
    protected void onResume(){
        super.onResume();
        handler.postDelayed(runnable,2000);
    }
    private void imageSlider(){
        ImageView imageView=findViewById(R.id.imageView);
        Glide.with(this).load(getIntent().getStringExtra("image")).into(imageView);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(ImageSliderActivity.this, "click ", Toast.LENGTH_SHORT).show();

            }
        });
        imageView.setClickable(true);
        imageView.setOnContextClickListener(new View.OnContextClickListener() {
            @Override
            public boolean onContextClick(View v) {
                Toast.makeText(ImageSliderActivity.this, "click ", Toast.LENGTH_SHORT).show();

                return false;
            }
        });
        ArrayList<SlideModel> imageList = new ArrayList<>(); // Create image list

        imageList.add(new SlideModel("https://bit.ly/2YoJ77H", "The animal population decreased by 58 percent in 42 years.",ScaleTypes.CENTER_CROP));
        imageList.add(new SlideModel("https://bit.ly/2BteuF2", "Elephants and tigers may become extinct.",ScaleTypes.CENTER_CROP));
        imageList.add(new SlideModel("https://bit.ly/3fLJf72", "And people do that.",ScaleTypes.CENTER_CROP));

        ImageSlider imageSlider = findViewById(R.id.image_slider);

        imageSlider.setImageList(imageList);
    }
    private void imageSlider2(){
         ItemsListener listener;
        ArrayList<ImageSlidesModel> autoImageList = new ArrayList<>();

        // find and initialize ImageSlider
        AutoImageSlider autoImageSlider = findViewById(R.id.autoImageSlider);

        // add some imagees or titles (text) inside the imagesArrayList
        autoImageList.add(new ImageSlidesModel("https://picsum.photos/id/237/200/300", "First image"));
        autoImageList.add(new ImageSlidesModel("https://picsum.photos/id/238/200/300", "Second image"));
        autoImageList.add(new ImageSlidesModel("https://picsum.photos/id/239/200/300", "Third image"));

        // set the added images inside the AutoImageSlider
        autoImageSlider.setImageList(autoImageList, ImageScaleType.FIT);

        // set any default animation or custom animation (setSlideAnimation(ImageAnimationTypes.ZOOM_IN))
        autoImageSlider.setSlideAnimation(ImageAnimationTypes.ZOOM_IN);
        autoImageSlider.onItemClickListener(new ItemsListener() {
            @Override
            public void onItemChanged(int i) {
                Toast.makeText(ImageSliderActivity.this, "change "+i, Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onTouched(@Nullable ImageActionTypes imageActionTypes, int i) {
                Toast.makeText(ImageSliderActivity.this, "touch "+i, Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onItemClicked(int i) {
                Toast.makeText(ImageSliderActivity.this, "clicked "+i, Toast.LENGTH_SHORT).show();
            }
        });


        // handle click event on item click

    }
}