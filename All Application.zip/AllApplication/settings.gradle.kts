pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
        jcenter()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        jcenter()
        maven{
            url=uri("https://jitpack.io")
        }
        maven{
            url=uri("https://download2.dynamsoft.com/maven/dce/aar")
        }

    }
}

rootProject.name = "All Application"
include(":app")
include(":QR")
